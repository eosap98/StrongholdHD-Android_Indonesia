"""Filter the pinned Stronghold hover-context load, without writing game state."""
import io
import struct
from pathlib import Path
from elftools.dwarf.callframe import FDE
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
from scenario_native_patch import ROOT, INPUT_SHA256, PC_RELATIVE, flags, run, sha, branch

DISPATCH = 0x2A1CA78
RENDERER = 0xDCE978
RENDERER_SIZE = 47100
RENDERER_SHA = '835aa5ff6d289d9674be0ba4ecff608deaab5d4444b42caa0d2f51ba22bff1d9'
SITE = 0xDD7698
RESUME = SITE + 4
BEFORE = '13cd41b9'  # ldr w19,[x8,#0x1cc], x8 = GPTR(0xABC378)
ENTRY = 'stronghold_original_pointer_entry'


def verify(image):
    if sha(image.data) != INPUT_SHA256['stronghold']:
        raise ValueError('unsupported original pointer library identity')
    at = image.offset(DISPATCH, 16)
    rels = [r for r in image.elf.get_section_by_name('.rela.dyn').iter_relocations()
            if r['r_offset'] == DISPATCH + 8]
    if (image.data[at:at+8] != struct.pack('<Q', 0x4B5110) or len(rels) != 1 or
        rels[0]['r_info_type'] != 1027 or rels[0]['r_addend'] != RENDERER):
        raise ValueError('original world renderer dispatch changed')
    bodies = [f for f in image.elf.get_dwarf_info().EH_CFI_entries()
              if isinstance(f, FDE) and f.header.initial_location == RENDERER]
    at = image.offset(RENDERER, RENDERER_SIZE)
    if (len(bodies) != 1 or bodies[0].header.address_range != RENDERER_SIZE or
        sha(image.data[at:at+RENDERER_SIZE]) != RENDERER_SHA):
        raise ValueError('original world renderer body changed')
    at = image.offset(SITE-12, 20)
    # Pin the complete address construction, displaced load and next compare.
    if image.data[at:at+20].hex() != '086f98d26815a0f20804c0f213cd41b97fa20f71':
        raise ValueError('original hover load/context register changed')
    return dict(input_sha256=sha(image.data), guest_renderer='0x4b5110',
        dispatch=hex(DISPATCH), renderer=hex(RENDERER), renderer_size=RENDERER_SIZE,
        renderer_sha256=RENDERER_SHA, guest_load='0x4b83ef', site=hex(SITE),
        before=BEFORE, resume=hex(RESUME), result_register='w19',
        global_context='0xabc544', global_context_unchanged=True)


def trampoline():
    lines = ['.section .text.'+ENTRY+', "ax", @progbits', '.p2align 2',
             '.global '+ENTRY, '.hidden '+ENTRY, '.type '+ENTRY+', %function',
             ENTRY+':', 'sub sp, sp, #784']
    for i in range(0, 30, 2):
        lines.append(f'stp x{i}, x{i+1}, [sp, #{i*8}]')
    lines += ['str x30, [sp, #240]', 'mrs x9, nzcv', 'str x9, [sp, #248]']
    for i in range(0, 32, 2):
        lines.append(f'stp q{i}, q{i+1}, [sp, #{256+i*16}]')
    lines += ['mrs x9, fpcr', 'str x9, [sp, #768]',
              'mrs x9, fpsr', 'str x9, [sp, #776]',
              'ldr w0, [x8, #0x1cc]',  # Replay the displaced guest-memory read.
              'bl stronghold_original_pointer_context',
              'uxtw x0, w0',          # A uint32_t C return has no upper-bit contract.
              'str x0, [sp, #152]',    # Only w19 changes, zero-extended like LDR W.
              'ldr x9, [sp, #768]', 'msr fpcr, x9',
              'ldr x9, [sp, #776]', 'msr fpsr, x9',
              'ldr x9, [sp, #248]', 'msr nzcv, x9']
    for i in range(0, 32, 2):
        lines.append(f'ldp q{i}, q{i+1}, [sp, #{256+i*16}]')
    for i in range(0, 30, 2):
        lines.append(f'ldp x{i}, x{i+1}, [sp, #{i*8}]')
    lines += ['ldr x30, [sp, #240]', 'add sp, sp, #784', 'b __pointer_resume',
              '.size '+ENTRY+', .-'+ENTRY]
    return '\n'.join(lines)+'\n'


def prepare(image, clang, work):
    record = verify(image)
    work = Path(work)
    source = ROOT/'android/host/original_pointer.c'
    helper, stub = work/'original_pointer.o', work/'original_pointer_entry.o'
    opts = flags('stronghold') + ['-ffunction-sections', '-fdata-sections',
        '-fno-stack-protector', '-fno-unwind-tables', '-fno-asynchronous-unwind-tables',
        '-Dvoid_vm_readable=stronghold_pointer_readable',
        '-Dstronghold_touch_desktop=stronghold_pointer_desktop']
    run(clang, *opts, '-c', source, '-o', helper)
    assembly = work/'original_pointer_entry.s'
    assembly.write_text(trampoline())
    run(clang, '--target=aarch64-linux-android28', '-c', assembly, '-o', stub)
    bindings = {'__pointer_resume': RESUME,
        'stronghold_pointer_readable': image.address('lord_memory', 'void_vm_readable'),
        'stronghold_pointer_desktop': image.address('stronghold_original', 'stronghold_touch_desktop')}
    for obj in (helper, stub):
        elf = ELFFile(io.BytesIO(obj.read_bytes()))
        for sec in elf.iter_sections():
            if isinstance(sec, RelocationSection):
                if any(r['r_info_type'] not in PC_RELATIVE for r in sec.iter_relocations()):
                    raise ValueError('unsafe pointer patch relocation')
            elif sec['sh_flags'] & 3 == 3 and sec['sh_size']:
                raise ValueError('pointer patch introduced mutable storage')
    record.update(helper_source_sha256=sha(source.read_bytes()), compiler_flags=opts,
        bindings={k: hex(v) for k, v in bindings.items()},
        trampoline_sha256=sha(assembly.read_bytes()),
        objects={p.name: sha(p.read_bytes()) for p in (helper, stub)},
        preserved=['x0-x18', 'x20-x30', 'q0-q31', 'SP', 'NZCV', 'FPCR', 'FPSR'],
        active_rejection_guard='stronghold_touch_lord_control',
        destination_renderer_unchanged=True)
    return [helper, stub], bindings, record


def apply(result, image, symbols):
    verify(image)
    for name in (ENTRY, 'stronghold_original_pointer_context', 'stronghold_touch_lord_control'):
        if name not in symbols:
            raise ValueError('pointer payload missing '+name)
    at = image.offset(SITE, 4)
    after = branch(SITE, symbols[ENTRY])
    result[at:at+4] = after
    return dict(unit='original_pointer', function=ENTRY, original_va=hex(SITE),
        new_va=hex(symbols[ENTRY]), offset=at, before=BEFORE, after=after.hex()), (at, at+4)
