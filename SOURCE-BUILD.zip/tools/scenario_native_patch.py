"""Compile reviewed host fixes into SHA-pinned, stripped upstream ARM64 libraries.

Reconstruct symbols by matching a baseline object against the shipped code with
relocations masked, then decode its PC-relative references. Replacement code
reuses original mutable state and exports; it needs no dynamic relocations.
No game instructions or Android emulator are executed by this builder.
"""
import argparse
import hashlib
import io
import json
import os
import re
import struct
import subprocess
from collections import defaultdict
from pathlib import Path
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
from baseline_sources import baseline_source

ROOT = Path(__file__).resolve().parents[1]
BASE_COMMIT = 'ffe2e9722f5ab37a0b6a14af27f0e502af3996a0'
NDK_DEFAULT = Path(os.environ.get('ANDROID_NDK') or
    Path(os.environ.get('ANDROID_SDK') or os.environ.get('ANDROID_HOME') or
         os.environ.get('ANDROID_SDK_ROOT') or Path.home() / 'Android/Sdk') / 'ndk/27.2.12479018')
INPUT_SHA256 = {
 'extreme': '069b816a36d630feb228db25fd52804bf686213df9344f70be8694a4cdede44e',
 'classic': '61b519cd8a225879bec1c6552b2accd10ad41e80160a3b63c01833b7ce9f3073',
 'stronghold': '6ef43df580a8394189067711c2f90e9eb1146fd75dca81ada474e49c98da892d',
}
ROOTS = {
 'classic': {'touch': ['stronghold_touch_order', 'stronghold_touch_placement', 'stronghold_touch_after_world'],
             'game_ui': ['stronghold_game_command', 'stronghold_game_ui_frame'],
             'display': ['stronghold_display_ui_end', 'stronghold_display_world_begin']},
 'extreme': {'touch': ['stronghold_touch_order', 'stronghold_touch_placement', 'stronghold_touch_after_world'],
             'game_ui': ['stronghold_game_command', 'stronghold_game_ui_frame'],
             'display': ['stronghold_display_ui_end', 'stronghold_display_world_begin']},
 'stronghold': {'stronghold_original': ['stronghold_original_edge', 'stronghold_original_present',
                                      'stronghold_game_command', 'button_worker', 'cancel_aim', 'press', 'release',
                                      'stronghold_touch_abort', 'stronghold_touch_lord_control',
                                      'stronghold_touch_enqueue', 'stronghold_original_frame']},
}
PC_RELATIVE = {260,261,262,273,274,275,276,277,278,279,280,282,283,284,285,286,299}
LOW_SCALE = {277:0,278:0,284:1,285:2,286:3,299:4,312:3}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(*args):
    p = subprocess.run([str(x) for x in args], cwd=ROOT, capture_output=True, text=True)
    if p.returncode:
        raise RuntimeError(f'{args[0]} failed: {p.stderr}')
    return p.stdout


def sign(value, bits):
    return value - (1 << bits) if value & (1 << (bits - 1)) else value


def branch(src, dst):
    delta = dst-src
    if delta % 4 or not -(1 << 27) <= delta < (1 << 27):
        raise ValueError('replacement entry outside AArch64 branch range')
    return struct.pack('<I', 0x14000000 | ((delta >> 2) & 0x3ffffff))


def flags(edition):
    result = ['--target=aarch64-linux-android28', '-fno-strict-aliasing', '-fwrapv',
        '-fvisibility=hidden', '-fPIC', '-ffp-contract=off', '-fno-math-errno',
        '-g0', '-O2', '-std=gnu11', '-DRECOMP_TRACE', '-DVOID_ANDROID_APP',
        '-Iandroid/runtime', '-Iandroid/host']
    if edition == 'classic': result.append('-DSTRONGHOLD_CLASSIC')
    if edition == 'stronghold': result.append('-DSTRONGHOLD_ORIGINAL')
    return result


class Image:
    def __init__(self, data):
        self.data = data
        self.elf = ELFFile(io.BytesIO(data))
        if self.elf['e_machine'] != 'EM_AARCH64' or self.elf['e_type'] != 'ET_DYN':
            raise ValueError('expected AArch64 shared library')
        self.loads = [(i,s) for i,s in enumerate(self.elf.iter_segments()) if s['p_type']=='PT_LOAD']
        self.symbols = {}
        self.storage = {}
        self.gots = {}
        self.plt = {}
        for sec in self.elf.iter_sections():
            if not isinstance(sec, RelocationSection): continue
            table = self.elf.get_section(sec['sh_link'])
            for i,rel in enumerate(sec.iter_relocations()):
                name = table.get_symbol(rel['r_info_sym']).name
                if name:
                    self.gots[name] = rel['r_offset']
                    if sec.name == '.rela.plt':
                        self.plt[name] = self.elf.get_section_by_name('.plt')['sh_addr'] + 32 + 16*i

    def offset(self, va, size=1):
        for _,s in self.loads:
            if s['p_vaddr'] <= va and va+size <= s['p_vaddr']+s['p_filesz']:
                return s['p_offset']+va-s['p_vaddr']
        raise ValueError(f'not file-backed: {va:#x}')

    def address(self, unit, name):
        values = self.symbols[unit].get(name, set())
        if len(values)==1: return next(iter(values))
        if not values and name in self.plt: return self.plt[name]
        raise ValueError(f'{unit}: unresolved/ambiguous {name}: {values}')

    def has(self, unit, name):
        try: self.address(unit,name); return True
        except ValueError: return False

    def recover(self, obj, unit, anchor):
        elf = ELFFile(io.BytesIO(obj.read_bytes()))
        table = elf.get_section_by_name('.symtab')
        textsec = elf.get_section_by_name('.text')
        code = textsec.data()
        reloc = list(elf.get_section_by_name('.rela.text').iter_relocations())
        masked = set()
        for rel in reloc: masked.update(range(rel['r_offset'], rel['r_offset']+4))
        func = next(s for s in table.iter_symbols() if s.name==anchor)
        lo,hi=func['st_value'],func['st_value']+func['st_size']
        runs=[]; start=lo
        for i in range(lo,hi+1):
            if i==hi or i in masked:
                if i>start: runs.append((i-start,start))
                start=i+1
        size,start=max(runs)
        if size<16: raise ValueError('baseline anchor too short')
        needle=code[start:start+size]
        candidates=[]
        for _,s in self.loads:
            if not s['p_flags'] & 1: continue
            at=self.data.find(needle,s['p_offset'],s['p_offset']+s['p_filesz'])
            while at!=-1:
                base=at-start
                if base>=s['p_offset'] and base+len(code)<=s['p_offset']+s['p_filesz']:
                    if all(code[i]==self.data[base+i] for i in range(len(code)) if i not in masked):
                        candidates.append((base,base+s['p_vaddr']-s['p_offset']))
                at=self.data.find(needle,at+1,s['p_offset']+s['p_filesz'])
        if len(candidates)!=1:
            raise ValueError(f'{unit}: baseline text match count {len(candidates)}, expected 1')
        offset,base=candidates[0]
        bases=defaultdict(set); bases[elf.get_section_index('.text')].add(base)
        values=defaultdict(set)
        def word(r): return struct.unpack_from('<I',self.data,offset+r['r_offset'])[0]
        for i,rel in enumerate(reloc):
            sym=table.get_symbol(rel['r_info_sym']); kind=rel['r_info_type']; ins=word(rel)
            pc=base+rel['r_offset']
            if kind in (282,283):
                values[sym.name].add(pc+sign(ins&0x3ffffff,26)*4-rel['r_addend']-sym['st_value'])
            if kind not in (275,311): continue
            # lld may relax ADRP+ADD into NOP+ADR when the target is within
            # one MiB. Decode the linked pair, not the original opcode shape.
            if kind == 275 and ins == 0xd503201f:
                low = next((r for r in reloc[i+1:i+3]
                    if r['r_offset'] == rel['r_offset']+4 and r['r_info_type'] == 277
                    and r['r_info_sym'] == rel['r_info_sym'] and r['r_addend'] == rel['r_addend']), None)
                if low is None or word(low) & 0x9f000000 != 0x10000000:
                    raise ValueError(f'{unit}: unsupported relaxed ADRP at {pc:#x}')
                adr = word(low)
                target = pc+4+sign(((adr>>29)&3)|(((adr>>5)&0x7ffff)<<2),21)-rel['r_addend']
                if isinstance(sym['st_shndx'],int):
                    bases[sym['st_shndx']].add(target-sym['st_value'])
                elif sym.name:
                    values[sym.name].add(target)
                continue
            if ins & 0x9f000000 != 0x90000000:
                raise ValueError(f'{unit}: unsupported ADRP encoding at {pc:#x}')
            page=(pc&~4095)+(sign(((ins>>29)&3)|(((ins>>5)&0x7ffff)<<2),21)<<12)
            for low in reloc[i+1:i+16]:
                if low['r_offset']-rel['r_offset']>100: break
                typ=low['r_info_type']
                if typ not in LOW_SCALE or low['r_info_sym']!=rel['r_info_sym'] or low['r_addend']!=rel['r_addend']: continue
                li=word(low)
                if ((li>>5)&31)!=(ins&31): continue
                target=page+(((li>>10)&4095)<<LOW_SCALE[typ])-rel['r_addend']
                if kind==311:
                    self.gots.setdefault(unit+':'+sym.name,target)
                elif isinstance(sym['st_shndx'],int):
                    bases[sym['st_shndx']].add(target-sym['st_value'])
                elif sym.name:
                    values[sym.name].add(target)
                break
        for sym in table.iter_symbols():
            if not sym.name or not isinstance(sym['st_shndx'],int): continue
            section=elf.get_section(sym['st_shndx'])
            if len(bases[sym['st_shndx']])==1:
                values[sym.name].add(next(iter(bases[sym['st_shndx']]))+sym['st_value'])
        # CALL relocations to defined symbols give a section base, not a new
        # function address. The complete text byte match supplies their value.
        for sym in table.iter_symbols():
            if sym.name and sym['st_shndx']==elf.get_section_index('.text'):
                values[sym.name]={base+sym['st_value']}
        self.symbols[unit]=values
        self.storage[unit]={s.name:s['st_size'] for s in table.iter_symbols()
            if s.name and isinstance(s['st_shndx'],int) and s['st_info']['type']=='STT_OBJECT'
            and elf.get_section(s['st_shndx'])['sh_flags'] & 1}
        return {'unit':unit,'baseline_object_sha256':sha(obj.read_bytes()),
                'text_va':hex(base),'text_bytes_matched':len(code),'relocation_bytes_masked':len(masked),
                'section_bases':{elf.get_section(k).name:[hex(v) for v in sorted(vs)] for k,vs in bases.items() if len(vs)==1}}


def assembly_sections(content):
    sections={}; current=None
    for line in content.splitlines(True):
        match=re.match(r'\s*\.section\s+([^,\s]+)',line)
        if match: current=match[1]
        if current: sections.setdefault(current,[]).append(line)
    return {k:''.join(v) for k,v in sections.items()}


def compile_patch(clang, work, edition, unit, roots, image):
    source=ROOT/'android/host'/f'{unit}.c'
    assembly=work/f'{unit}.full.s'; obj=work/f'{unit}.full.o'
    opts=flags(edition)+['-ffunction-sections','-fdata-sections','-fno-jump-tables',
        '-fno-unwind-tables','-fno-asynchronous-unwind-tables','-fno-stack-protector']
    # Original's geometry arrays are scalarized after inlining in the shipped
    # object (unused HUD/book elements have no storage). Retain that pipeline
    # so replacement code binds the same individual variables, not a new array.
    if unit != 'stronghold_original': opts.append('-fno-inline')
    run(clang,*opts,'-S',source,'-o',assembly)
    run(clang,'--target=aarch64-linux-android28','-c',assembly,'-o',obj)
    elf=ELFFile(io.BytesIO(obj.read_bytes())); table=elf.get_section_by_name('.symtab')
    storage={s.name:s['st_size'] for s in table.iter_symbols()
        if s.name and isinstance(s['st_shndx'],int) and s['st_info']['type']=='STT_OBJECT'
        and elf.get_section(s['st_shndx'])['sh_flags'] & 1}
    required={elf.get_section_index('.text.'+name) for name in roots}
    if None in required: raise ValueError('replacement root not emitted')
    queue=list(required)
    relocs={s['sh_info']:s for s in elf.iter_sections() if isinstance(s,RelocationSection)}
    while queue:
        index=queue.pop()
        if index not in relocs: continue
        for rel in relocs[index].iter_relocations():
            sym=table.get_symbol(rel['r_info_sym'])
            if not isinstance(sym['st_shndx'],int): continue
            section=elf.get_section(sym['st_shndx'])
            if section.name.startswith('.text.') and sym['st_shndx'] not in required:
                if not image.has(unit,section.name[6:]):
                    required.add(sym['st_shndx']);queue.append(sym['st_shndx'])
    sections=assembly_sections(assembly.read_text())
    keep=sorted(elf.get_section(i).name for i in required)
    asm='.text\n'+''.join(sections[n] for n in keep+sorted(n for n in sections if n.startswith('.rodata')))
    asm='\n'.join(line for line in asm.splitlines() if not re.match(r'\s*\.(addrsig|addrsig_sym|ident|weak)',line))+'\n'
    got_names=set(re.findall(r':got:([\w.]+)',asm))
    for name in got_names:
        asm=asm.replace(':got:'+name,'__got_'+unit+'_'+name).replace(':got_lo12:'+name,':lo12:__got_'+unit+'_'+name)
    subset=work/f'{unit}.patch.s';obj=work/f'{unit}.patch.o'
    subset.write_text(asm);run(clang,'--target=aarch64-linux-android28','-c',subset,'-o',obj)
    elf=ELFFile(io.BytesIO(obj.read_bytes()));bindings={};aliases=[]
    for sym in elf.get_section_by_name('.symtab').iter_symbols():
        if not sym.name or sym['st_shndx']!='SHN_UNDEF':continue
        name=sym.name
        if name.startswith('__got_'+unit+'_'):
            original=name[len('__got_'+unit+'_'):]
            value=image.gots.get(unit+':'+original,image.gots.get(original))
            if value is None:raise ValueError(f'{unit}: unknown original GOT {original}')
            bindings[name]=value
        else:
            if name in storage and image.storage[unit].get(name) != storage[name]:
                raise ValueError(f'{unit}: storage width changed for {name}: '
                    f'{image.storage[unit].get(name)} -> {storage[name]}')
            bound='__bound_'+unit+'_'+name
            bindings[bound]=image.address(unit,name)
            aliases.append(f'.set {name}, {bound}\n')
    subset.write_text(''.join(aliases)+asm);run(clang,'--target=aarch64-linux-android28','-c',subset,'-o',obj)
    elf=ELFFile(io.BytesIO(obj.read_bytes()))
    for sec in elf.iter_sections():
        if isinstance(sec,RelocationSection):
            for rel in sec.iter_relocations():
                if rel['r_info_type'] not in PC_RELATIVE:raise ValueError(f'unsafe patch relocation {rel["r_info_type"]}')
        elif sec['sh_flags']&3==3 and sec['sh_size']:
            raise ValueError(f'new mutable state disallowed: {sec.name}')
    return obj,bindings,{'unit':unit,'roots':roots,'compiled_sections':keep,'source_sha256':sha(source.read_bytes()),
        'compiler_flags':opts,'bindings':{k:hex(v) for k,v in sorted(bindings.items())}}


def patch_library(input_path, output_path, edition, work_dir, ndk=NDK_DEFAULT):
    source=Path(input_path);output=Path(output_path);work=Path(work_dir);ndk=Path(ndk)
    data=source.read_bytes()
    if sha(data)!=INPUT_SHA256.get(edition):raise ValueError(f'unsupported {edition} input SHA256: {sha(data)}')
    image=Image(data);work.mkdir(parents=True,exist_ok=True)
    bindir=ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin';clang=bindir/'clang'
    evidence=[];objects=[];bindings={};units=[]
    for unit,roots in ROOTS[edition].items():
        baseline=work/f'{unit}.baseline.c';obj=work/f'{unit}.baseline.o'
        baseline.write_text(baseline_source(f'android/host/{unit}.c'))
        run(clang,*flags(edition),'-c',baseline,'-o',obj)
        evidence.append(image.recover(obj,unit,roots[-1]))
        obj,bound,report=compile_patch(clang,work,edition,unit,roots,image)
        objects.append(obj);bindings.update(bound);units.append(report)
    lord_patch = lord_order_patch = pointer_patch = None
    if edition == 'stronghold':
        import original_lord_wall_patch
        extra, bound, lord_patch = original_lord_wall_patch.prepare(image=image, clang=clang, work=work)
        objects.extend(extra);bindings.update(bound)
        import original_lord_order_patch
        extra, bound, lord_order_patch = original_lord_order_patch.prepare(image=image, clang=clang, work=work)
        objects.extend(extra);bindings.update(bound)
        import original_pointer_patch
        extra, bound, pointer_patch = original_pointer_patch.prepare(image=image, clang=clang, work=work)
        objects.extend(extra);bindings.update(bound)
    append_offset=(len(data)+16383)&~16383
    append_va=(max(s['p_vaddr']+s['p_memsz'] for _,s in image.loads)+16383)&~16383
    script=work/'patch.ld';linked=work/'patch.elf'
    script.write_text(''.join(f'{k} = {v:#x};\n' for k,v in sorted(bindings.items()))+
        f'SECTIONS {{ .patch {append_va:#x} : {{ *(.text.*) *(.rodata*) }}\n'
        '/DISCARD/ : { *(.comment) *(.note*) *(.llvm_addrsig) *(.eh_frame*) } }\n')
    run(bindir/'ld.lld','-static','--no-undefined','-T',script,'-o',linked,*objects)
    elf=ELFFile(io.BytesIO(linked.read_bytes()))
    for sec in elf.iter_sections():
        if isinstance(sec,RelocationSection) and sec.num_relocations():raise ValueError('runtime relocations disallowed')
        if sec['sh_flags']&2 and sec['sh_size'] and sec.name!='.patch':raise ValueError(f'unexpected allocated section {sec.name}')
    payload=elf.get_section_by_name('.patch').data()
    symbols={s.name:s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols()}
    result=bytearray(data);result.extend(b'\0'*(append_offset-len(result))+payload)
    notes=[(i,s) for i,s in enumerate(image.elf.iter_segments()) if s['p_type']=='PT_NOTE']
    if len(notes)!=1:raise ValueError('expected one reusable NOTE program header')
    ni,note=notes[0]
    # NOTE bytes remain mapped by the original first read-only LOAD. All LOAD,
    # GNU_STACK and RELRO entries remain unchanged.
    image.offset(note['p_vaddr'],note['p_filesz'])
    ph=image.elf['e_phoff']+ni*image.elf['e_phentsize']
    if image.elf['e_phentsize']!=56:raise ValueError('unexpected program header width')
    result[ph:ph+56]=struct.pack('<IIQQQQQQ',1,5,append_offset,append_va,append_va,len(payload),len(payload),16384)
    ranges=[(ph,ph+56)];redirects=[]
    for unit,roots in ROOTS[edition].items():
        for name in roots:
            va=image.address(unit,name);off=image.offset(va,4);replacement=branch(va,symbols[name])
            result[off:off+4]=replacement;ranges.append((off,off+4))
            redirects.append({'unit':unit,'function':name,'original_va':hex(va),'new_va':hex(symbols[name]),
                'offset':off,'before':data[off:off+4].hex(),'after':replacement.hex()})
    if lord_patch is not None:
        redirect, changed_range = original_lord_wall_patch.apply(result, image, symbols)
        redirects.append(redirect);ranges.append(changed_range)
    if lord_order_patch is not None:
        extra_redirects, changed_ranges = original_lord_order_patch.apply(result, image, symbols)
        redirects.extend(extra_redirects);ranges.extend(changed_ranges)
    if pointer_patch is not None:
        redirect, changed_range = original_pointer_patch.apply(result, image, symbols)
        redirects.append(redirect);ranges.append(changed_range)
    restored=bytearray(result[:len(data)])
    for lo,hi in ranges:restored[lo:hi]=data[lo:hi]
    if bytes(restored)!=data:raise ValueError('unexpected changes outside reviewed ranges')
    patched=ELFFile(io.BytesIO(result))
    for section in ('.dynsym','.dynstr','.dynamic','.rela.dyn','.rela.plt'):
        before=image.elf.get_section_by_name(section);after=patched.get_section_by_name(section)
        if before and before.data()!=after.data():raise ValueError(f'{section} changed')
    for seg in patched.iter_segments():
        if seg['p_type']=='PT_LOAD' and (seg['p_align']<16384 or (seg['p_offset']-seg['p_vaddr'])%16384):
            raise ValueError('16 KiB page alignment violated')
    output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(result)
    report={'edition':edition,'input_sha256':sha(data),'output_sha256':sha(result),'baseline_commit':BASE_COMMIT,
        'baseline_matching':evidence,'units':units,'redirects':redirects,'unchanged_outside_redirects_and_program_header':True,
        'dynamic_symbols_and_relocations_preserved':True,'page_alignment':16384,
        'segment':{'file_offset':append_offset,'va':hex(append_va),'bytes':len(payload),'flags':'RX','reused_note_index':ni}}
    if lord_patch is not None: report['lord_wall_seam'] = lord_patch
    if lord_order_patch is not None: report['lord_order_seams'] = lord_order_patch
    if pointer_patch is not None: report['pointer_seam'] = pointer_patch
    (work/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path);parser.add_argument('output',type=Path)
    parser.add_argument('--edition',choices=ROOTS,required=True);parser.add_argument('--work',type=Path,required=True)
    parser.add_argument('--ndk',type=Path,default=NDK_DEFAULT)
    args=parser.parse_args()
    print(json.dumps(patch_library(args.source,args.output,args.edition,args.work,args.ndk),indent=2))
