"""Four pinned Stronghold selection/permission calls; no game execution."""
import io
import struct
from pathlib import Path
from elftools.dwarf.callframe import FDE
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection

import original_lord_wall_patch as wall
from scenario_native_patch import ROOT, BASE_COMMIT, PC_RELATIVE, flags, run, sha, branch
from baseline_sources import baseline_source

HELPERS = {
    'sub_004F8320': (0x4F8320, 0x2A22018, 0x234E1F4, 696,
        'db9328a80bbc2c948ba582d7ea2f7060725d1b864f13e421c38852507cf19abe'),
    'sub_004F8390': (0x4F8390, 0x2A22028, 0x234E4AC, 1548,
        '93f0982c40f06a9b432f760ec969b5072c652552fc15826d261c043f816688d8'),
    'sub_004F8460': (0x4F8460, 0x2A22038, 0x234EAB8, 1448,
        '37caf77d1edc6f15bbc136ccf302c9ba4f40b6347651bd01bb41ba8e70aed966'),
}
CALLS = (
    (0x12BBD84, 'ca494294', 'sub_004F8390', 'stronghold_original_touch_group', 'selection'),
    (0x12C42B4, 'd0274294', 'sub_004F8320', 'stronghold_original_touch_lord', 'final_permission'),
    (0x12C52F8, 'bf234294', 'sub_004F8320', 'stronghold_original_touch_lord', 'ground_target'),
    (0x12C55F0, '01234294', 'sub_004F8320', 'stronghold_original_touch_lord', 'release_permission'),
)


def call_branch(source, destination):
    word, = struct.unpack('<I', branch(source, destination))
    return struct.pack('<I', word | 0x80000000)  # BL, retaining the callsite's LR.


def verify(image):
    identity = wall.verify(image)
    rels = {r['r_offset']: r for r in image.elf.get_section_by_name('.rela.dyn').iter_relocations()}
    bodies = {f.header.initial_location: f.header.address_range
              for f in image.elf.get_dwarf_info().EH_CFI_entries() if isinstance(f, FDE)}
    helpers = {}
    for name, (guest, entry, native, size, digest) in HELPERS.items():
        at = image.offset(entry, 16)
        rel = rels.get(entry+8)
        if (image.data[at:at+8] != struct.pack('<Q', guest) or rel is None or
            rel['r_info_type'] != 1027 or rel['r_addend'] != native or bodies.get(native) != size):
            raise ValueError('lord order helper identity changed: '+name)
        at = image.offset(native, size)
        if sha(image.data[at:at+size]) != digest:
            raise ValueError('lord order helper body changed: '+name)
        helpers[name] = dict(guest=hex(guest), dispatch=hex(entry), native=hex(native),
                             size=size, sha256=digest)
    for site, before, helper, _, _ in CALLS:
        at = image.offset(site, 4)
        if (image.data[at:at+4].hex() != before or
            image.data[at:at+4] != call_branch(site, HELPERS[helper][2])):
            raise ValueError('lord order callsite changed: '+hex(site))
    return dict(input_sha256=identity['input_sha256'], callback_sha256=identity['callback_sha256'],
                guest_callback=identity['guest_callback'], helpers=helpers)


def prepare(image, clang, work):
    record = verify(image)
    work = Path(work)
    # Recover globals by matching all baseline core.c text, not by assuming
    # g_eax/g_esp addresses from an older release's register layout.
    baseline, obj = work/'lord_order_core.baseline.c', work/'lord_order_core.baseline.o'
    baseline.write_text(baseline_source('android/host/core.c'))
    run(clang, *flags('stronghold'), '-c', baseline, '-o', obj)
    core = image.recover(obj, 'lord_order_core', 'void_regs_save')
    bindings = {name: row[2] for name, row in HELPERS.items()}
    bindings.update({
        'stronghold_order_eax': image.address('lord_order_core', 'g_eax'),
        'stronghold_order_esp': image.address('lord_order_core', 'g_esp'),
        'stronghold_order_vm_readable': image.address('lord_memory', 'void_vm_readable'),
        'stronghold_order_vm_writable': image.address('lord_memory', 'void_vm_writable'),
        'stronghold_order_desktop': image.address('stronghold_original', 'stronghold_touch_desktop'),
    })
    source, helper = ROOT/'android/host/original_lord_order.c', work/'original_lord_order.o'
    opts = flags('stronghold') + ['-ffunction-sections', '-fdata-sections',
        '-fno-stack-protector', '-fno-unwind-tables', '-fno-asynchronous-unwind-tables',
        '-Dg_eax=stronghold_order_eax', '-Dg_esp=stronghold_order_esp',
        '-Dvoid_vm_readable=stronghold_order_vm_readable',
        '-Dvoid_vm_writable=stronghold_order_vm_writable',
        '-Dstronghold_touch_desktop=stronghold_order_desktop']
    run(clang, *opts, '-c', source, '-o', helper)
    elf = ELFFile(io.BytesIO(helper.read_bytes()))
    for sec in elf.iter_sections():
        if isinstance(sec, RelocationSection):
            if any(r['r_info_type'] not in PC_RELATIVE for r in sec.iter_relocations()):
                raise ValueError('unsafe lord order relocation')
        elif sec['sh_flags'] & 3 == 3 and sec['sh_size']:
            raise ValueError('lord order helper introduced mutable storage')
    record.update(helper_source_sha256=sha(source.read_bytes()), core_binding=core,
                  bindings={k: hex(v) for k, v in bindings.items()},
                  compiler_flags=opts, object_sha256=sha(helper.read_bytes()),
                  permission_guard='stronghold_touch_lord_control',
                  group_guard='native controls and an active selected owned lord',
                  guest_permission_offset_after_query='0x14')
    return [helper], bindings, record


def apply(result, image, symbols):
    verify(image)
    if 'stronghold_touch_lord_control' not in symbols:
        raise ValueError('lord order payload lacks native transaction guard')
    redirects, ranges = [], []
    for site, before, helper, replacement, role in CALLS:
        if replacement not in symbols:
            raise ValueError('lord order payload lacks '+replacement)
        at = image.offset(site, 4)
        after = call_branch(site, symbols[replacement])
        result[at:at+4] = after
        ranges.append((at, at+4))
        redirects.append(dict(unit='original_lord_order', function=replacement, role=role,
            original_va=hex(site), original_callee=helper, new_va=hex(symbols[replacement]),
            offset=at, before=before, after=after.hex()))
    return redirects, ranges
