"""Check and build the portable Indonesian release on Linux x86_64 / WSL2."""
import argparse
import hashlib
import importlib.metadata
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sdk_default = os.environ.get('ANDROID_SDK') or os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT')
    parser.add_argument('--sdk', type=Path, default=Path(sdk_default) if sdk_default else None)
    parser.add_argument('--signing-dir', type=Path, default=ROOT/'private/signing')
    parser.add_argument('--work-root', type=Path, default=ROOT/'build/portable')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    if sys.version_info < (3, 11): parser.error('Python 3.11+ diperlukan.')
    if sys.platform != 'linux' or platform.machine().lower() not in ('x86_64', 'amd64'):
        parser.error('Pakai Linux x86_64 atau Ubuntu di WSL2; lihat BUILD-PC-BARU.md.')
    if args.sdk is None: parser.error('Tentukan --sdk /lokasi/Android/Sdk atau ANDROID_HOME.')
    sdk, signing = args.sdk.expanduser().resolve(), args.signing_dir.expanduser().resolve()
    for package, expected in (('pyelftools', '0.33'), ('pefile', '2024.8.26')):
        try: actual = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError: actual = None
        if actual != expected:
            parser.error('Pasang dependency: python -m pip install -r requirements-build.txt')
    for tool in ('java', 'javac', 'keytool', 'xz', 'readelf'):
        if not shutil.which(tool): parser.error('Tool belum tersedia di PATH: '+tool)
    for tool in ('java', 'javac'):
        version = subprocess.run([tool, '-version'], capture_output=True, text=True, check=True)
        match = re.search(r'(?:version\s+")?(\d+)(?:\.\d+)', version.stdout+version.stderr)
        if not match or int(match[1]) < 17: parser.error('Pakai JDK 17+ untuk java dan javac.')
    ndk = sdk/'ndk/27.2.12479018'
    required = [sdk/'platforms/android-36/android.jar',
        *(sdk/'build-tools/36.0.0'/name for name in ('aapt2', 'd8', 'zipalign', 'apksigner')),
        *(ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin'/name for name in ('clang', 'ld.lld')),
        signing/'stronghold-rev12.keystore', signing/'password.txt', ROOT/'inputs/upstream-1.0.apk',
        *(ROOT/'android/app/assets/language'/name for name in ('catalog.json', 'crusader.zip', 'stronghold.zip'))]
    missing = [str(path) for path in required if not path.is_file()]
    if missing: parser.error('Input belum lengkap (lihat BUILD-PC-BARU.md):\n'+'\n'.join(missing))
    from baseline_sources import verify_all
    from build_indonesian_apk import BASE_SHA256, CERT_SHA256
    from android_native_payload import xz_tool
    import language_assets
    verify_all()
    xz_tool()
    with (ROOT/'inputs/upstream-1.0.apk').open('rb') as source:
        if hashlib.file_digest(source, 'sha256').hexdigest() != BASE_SHA256:
            parser.error('SHA-256 APK upstream tidak cocok.')
    language_assets.verify()
    env = os.environ.copy()
    env['STRONGHOLD_SIGNING_PASSWORD'] = (signing/'password.txt').read_text().rstrip('\r\n')
    certificate = subprocess.run(['keytool', '-exportcert', '-keystore', str(signing/'stronghold-rev12.keystore'),
        '-alias', 'stronghold-rev12', '-storepass:env', 'STRONGHOLD_SIGNING_PASSWORD'],
        env=env, capture_output=True)
    if certificate.returncode or hashlib.sha256(certificate.stdout).hexdigest() != CERT_SHA256:
        parser.error('Kunci/password signing tidak cocok dengan sertifikat rilis sebelumnya.')
    print('PASS: toolchain, 6 baseline tanpa Git, input APK, paket bahasa, dan sertifikat signing.', flush=True)
    if args.check_only: return
    manifest = ET.parse(ROOT/'android/app/AndroidManifest.xml').getroot()
    version = manifest.attrib['{http://schemas.android.com/apk/res/android}versionName']
    output = (args.output or ROOT/'dist'/f'Stronghold-{version}-Indonesia.apk').expanduser().resolve()
    command = [sys.executable, str(ROOT/'tools/build_indonesian_apk.py'), '--sdk', str(sdk),
        '--signing-dir', str(signing), '--ndk', str(ndk), '--base-apk', str(ROOT/'inputs/upstream-1.0.apk'),
        '--work-root', str(args.work_root.expanduser().resolve()), '--output', str(output)]
    subprocess.run(command, cwd=ROOT, check=True)


if __name__ == '__main__': main()
