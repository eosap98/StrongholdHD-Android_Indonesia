"""Build the Indonesian launcher and scoped native fixes from the matching pinned release.

No emulator, ADB, Gradle, or game execution is used. Changed native host
functions are recompiled and installed with source-matched, checked redirects.
The original full AOT build remains available in build_apk.py.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile

import language_assets
from verify_elf_pages import inspect

ROOT = Path(__file__).resolve().parents[1]
BASE_SHA256 = '88265d0a14893e343850eb0b4cc84ea56f294dd129f09af1c9ab82f33a75588a'
BASE_COMMIT = 'ffe2e9722f5ab37a0b6a14af27f0e502af3996a0'
BASE_URL = ('https://github.com/phys-winner/pc_decomp_strhld/releases/download/'
            'v1.0-release/stronghold-crusader-1.0-release-88265d0a.apk')
CERT_SHA256 = 'b9c250d72a8ca35bd68b4a29e06592750e44079f3ad70d7dbb26c58253b9fe45'
GAMES = ('libstronghold.so', 'libstronghold_classic.so', 'libstronghold_sh.so')
ANDROID = '{http://schemas.android.com/apk/res/android}'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(*command, **kwargs):
    result = subprocess.run([str(x) for x in command], capture_output=True,
                            text=True, errors='replace', **kwargs)
    if result.returncode:
        raise RuntimeError(f'{Path(str(command[0])).name} failed:\n{result.stdout}\n{result.stderr}')
    return result.stdout + result.stderr


def java_key(text):
    value = 0
    encoded = text.encode('utf-16-be')
    for at in range(0, len(encoded), 2):
        value = (31 * value + int.from_bytes(encoded[at:at + 2], 'big')) & 0xffffffff
    return 'text_' + format(value, 'x')


def verify_translations(catalog):
    tables = []
    for locale in ('values', 'values-in'):
        elements = list(ET.parse(ROOT / f'android/app/res/{locale}/strings.xml').getroot())
        table = {e.attrib['name']: e.text for e in elements}
        assert len(elements) == len(table), 'Duplicate resource key'
        tables.append(table)
    original, translated = tables
    assert original.keys() <= translated.keys(), 'Incomplete Indonesian translation'
    for name, text in translated.items():
        assert text and not re.search('[\u0400-\u04ff]', text), name
        if name in original:
            pattern = r'%(?:\d+\$)?[.\d]*[a-zA-Z]'
            assert re.findall(pattern, text) == re.findall(pattern, original[name]), name
    for file in (ROOT / 'android/app/src').rglob('*.java'):
        for literal in re.findall(r'(?<![\w.])(?:I18n\.)?t\(("(?:\\.|[^"\\])*")\)', file.read_text()):
            assert java_key(json.loads(literal)) in translated, (file.name, literal)
    for group in ('features', 'categories'):
        for row in catalog[group]:
            for field in ('name', 'description'):
                text = row.get(field, '')
                assert not text.strip() or java_key(text) in translated, (row.get('id'), field)
    return len(translated)


def verify_native(apk, work):
    """Decode the actual final APK; verify each chunk, digest, ELF and Java native entry."""
    report = {}
    declarations = (ROOT / 'android/app/src/org/stronghold/port/GameActivity.java').read_text()
    methods = re.findall(r'\bnative\s+[\w\[\]]+\s+(\w+)\s*\(', declarations)
    index = apk.read('assets/native/index.txt').decode('ascii').splitlines()
    assert {line.split()[0] for line in index} == set(GAMES)
    for line in index:
        name, total, digest, chunk, sizes = line.split()
        total, chunk = int(total), int(chunk)
        packed_sizes = [int(s) for s in sizes.split(',')]
        compressed = apk.read('assets/native/' + name + '.xz')
        assert sum(packed_sizes) == len(compressed)
        target = work / name
        at = 0
        with target.open('wb') as output:
            for size in packed_sizes:
                decoded = subprocess.run(['xz', '--decompress', '--stdout'],
                    input=compressed[at:at + size], capture_output=True, check=True).stdout
                assert len(decoded) == min(chunk, total - output.tell()), name
                output.write(decoded)
                at += size
        data = target.read_bytes()
        assert len(data) == total and sha(data) == digest, name
        layout = inspect(data)
        symbols = run('readelf', '--dyn-syms', '--wide', target)
        for method in methods:
            assert 'Java_org_stronghold_port_GameActivity_' + method in symbols, (name, method)
        report[name] = dict(bytes=total, sha256=digest, elf_16kb=layout['status'],
                            jni_methods=len(methods), chunks=len(packed_sizes))
    for name in ('libinnoextract.so', 'libstronghold_xz.so'):
        data = apk.read('lib/arm64-v8a/' + name)
        target = work / name
        target.write_bytes(data)
        report[name] = dict(bytes=len(data), sha256=sha(data), elf_16kb=inspect(data)['status'])
        if name == 'libstronghold_xz.so':
            assert 'Java_org_stronghold_port_NativeLibrary_nativeUnpack' in run('readelf', '--dyn-syms', '--wide', target)
    return report


def patched_native(base, work, ndk):
    import scenario_native_patch
    import android_native_payload
    entries, reports, index = {}, {}, []
    source_dir, output_dir = work / 'native-input', work / 'native-patched'
    source_dir.mkdir(); output_dir.mkdir()
    editions = {'libstronghold.so': 'extreme', 'libstronghold_classic.so': 'classic', 'libstronghold_sh.so': 'stronghold'}
    source_index = {line.split()[0]: line.split() for line in base.read('assets/native/index.txt').decode('ascii').splitlines()}
    for name in GAMES:
        original = subprocess.run(['xz', '--decompress', '--stdout'],
            input=base.read('assets/native/' + name + '.xz'), capture_output=True, check=True).stdout
        assert len(original) == int(source_index[name][1]) and sha(original) == source_index[name][2], name
        source = source_dir / name; source.write_bytes(original); del original
        target = output_dir / name
        print(f'Compiling scoped native fixes: {editions[name]}…', flush=True)
        report = scenario_native_patch.patch_library(source, target, editions[name], work / ('patch-' + editions[name]), ndk=ndk)
        inspect(target.read_bytes())
        print(f'Compressing patched engine: {editions[name]}…', flush=True)
        packed, compression = android_native_payload.compress_library(target, work.parent / 'patched-xz-cache')
        android_native_payload.verify_chunk_table(packed, compression)
        entries['assets/native/' + name + '.xz'] = packed
        report['compression'] = compression
        reports[name] = report
        index.append(f'{name} {compression["bytes"]} {compression["sha256"]} {compression["chunk_bytes"]} '
                     + ','.join(map(str, compression['packed_sizes'])))
    table = output_dir / 'index.txt'; table.write_text('\n'.join(index) + '\n', encoding='ascii')
    entries['assets/native/index.txt'] = table
    return entries, reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', type=Path, required=True)
    parser.add_argument('--build-tools', default='36.0.0')
    parser.add_argument('--ndk', type=Path, help='Defaults to the SDK NDK 27.2.12479018')
    parser.add_argument('--base-apk', type=Path, default=ROOT / 'inputs/upstream-1.0.apk')
    parser.add_argument('--signing-dir', type=Path, required=True)
    parser.add_argument('--work-root', type=Path, default=Path('/var/tmp/stronghold-new-build'))
    parser.add_argument('--output', type=Path, default=ROOT.parent / 'Stronghold-1.6.6-Indonesia.apk')
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        parser.error(f'Output already exists; choose a new --output: {output}')
    build_tools = args.sdk / 'build-tools' / args.build_tools
    android = args.sdk / 'platforms/android-36/android.jar'
    for path in [android, *(build_tools / t for t in ('aapt2', 'd8', 'zipalign', 'apksigner')),
                 args.signing_dir / 'stronghold-rev12.keystore', args.signing_dir / 'password.txt']:
        if not path.is_file():
            parser.error(f'Missing build input: {path}')
    for tool in ('java', 'javac', 'xz', 'readelf'):
        if not shutil.which(tool):
            parser.error(f'Missing tool: {tool}')
    if not args.base_apk.is_file() or sha(args.base_apk.read_bytes()) != BASE_SHA256:
        parser.error(f'Pinned base APK missing or changed. Obtain {BASE_URL}\nSHA-256: {BASE_SHA256}')
    language_entries, language_catalog = language_assets.verify()
    args.work_root.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix='release-', dir=args.work_root))
    print(f'Work directory: {work}', flush=True)
    with zipfile.ZipFile(args.base_apk) as base:
        strings = verify_translations(json.loads(base.read('assets/ucp/catalog.json')))
        print(f'Validated {strings} Indonesian strings and both patch bundles.', flush=True)
        native_entries, native_patches = patched_native(base, work, args.ndk or args.sdk / 'ndk/27.2.12479018')
        sources = sorted((ROOT / 'android/app/src').rglob('*.java'))
        (work / 'classes').mkdir()
        (work / 'dex').mkdir()
        run(build_tools / 'aapt2', 'compile', '--dir', ROOT / 'android/app/res', '-o', work / 'resources.zip')
        run(build_tools / 'aapt2', 'link', '-I', android, '--manifest', ROOT / 'android/app/AndroidManifest.xml',
            '-A', ROOT / 'android/app/assets', '-o', work / 'base.apk', work / 'resources.zip')
        print('Compiling launcher Java and DEX…', flush=True)
        run('javac', '--release', '8', '-Xlint:-options', '-encoding', 'UTF-8', '-cp', android,
            '-d', work / 'classes', *sources)
        with zipfile.ZipFile(work / 'classes.jar', 'w') as jar:
            for path in sorted((work / 'classes').rglob('*.class')):
                jar.write(path, path.relative_to(work / 'classes').as_posix())
        run(build_tools / 'd8', '--lib', android, '--min-api', '28', '--output', work / 'dex', work / 'classes.jar')
        shutil.copyfile(work / 'base.apk', work / 'unsigned.apk')
        retained = {}
        with zipfile.ZipFile(work / 'unsigned.apk', 'a', zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
            existing = set(apk.namelist())
            apk.write(work / 'dex/classes.dex', 'classes.dex')
            for name, path in native_entries.items():
                apk.write(path, name, compress_type=zipfile.ZIP_STORED)
                existing.add(name)
            for item in base.infolist():
                if item.filename.startswith(('lib/', 'assets/')) and item.filename not in existing:
                    data = base.read(item)
                    apk.writestr(item, data)
                    retained[item.filename] = sha(data)
        run(build_tools / 'zipalign', '-f', '-P', '16', '4', work / 'unsigned.apk', work / 'aligned.apk')
        environment = os.environ.copy()
        environment['STRONGHOLD_SIGNING_PASSWORD'] = (args.signing_dir / 'password.txt').read_text().rstrip('\r\n')
        run(build_tools / 'apksigner', 'sign', '--ks', args.signing_dir / 'stronghold-rev12.keystore',
            '--ks-key-alias', 'stronghold-rev12', '--ks-pass', 'env:STRONGHOLD_SIGNING_PASSWORD',
            '--key-pass', 'env:STRONGHOLD_SIGNING_PASSWORD', '--out', work / 'signed.apk', work / 'aligned.apk', env=environment)
        signature = run(build_tools / 'apksigner', 'verify', '--verbose', '--print-certs', work / 'signed.apk')
        assert CERT_SHA256 in signature.lower(), 'Signing certificate differs from the previous user release'
        run(build_tools / 'zipalign', '-c', '-P', '16', '4', work / 'signed.apk')
        print('Verifying final APK, native decompression, JNI, and 16 KB alignment…', flush=True)
        with zipfile.ZipFile(work / 'signed.apk') as apk:
            assert apk.testzip() is None and len(apk.namelist()) == len(set(apk.namelist()))
            for name, digest in retained.items():
                assert sha(apk.read(name)) == digest, name
            for name, data in language_entries.items():
                assert apk.read(name) == data, name
            native = verify_native(apk, work)
            for name, patch in native_patches.items():
                assert native[name]['sha256'] == patch['output_sha256'], name
        badging = run(build_tools / 'aapt2', 'dump', 'badging', work / 'signed.apk')
        assert "application-label:'Stronghold'" in badging
        assert "native-code: 'arm64-v8a'" in badging
        manifest = ET.parse(ROOT / 'android/app/AndroidManifest.xml').getroot()
        version = manifest.attrib[ANDROID + 'versionName']
        code = manifest.attrib[ANDROID + 'versionCode']
        assert f"versionCode='{code}'" in badging and f"versionName='{version}'" in badging
        (work / 'badging.txt').write_text(badging)
        (work / 'signature.txt').write_text(signature)
        report = dict(status='PASS', version=version, version_code=int(code), package='org.stronghold.port',
            apk_sha256=sha((work / 'signed.apk').read_bytes()), apk_bytes=(work / 'signed.apk').stat().st_size,
            source_base=dict(commit=BASE_COMMIT, url=BASE_URL, sha256=BASE_SHA256),
            build_type='Java launcher and scoped native host fixes compiled from source against pinned upstream engines',
            native=native, native_patches=native_patches, retained_assets=retained, signing_certificate_sha256=CERT_SHA256,
            indonesian_strings=strings, language_patches={k: {'files': v['file_count'], 'sha256': v['sha256']}
                for k, v in language_catalog['patches'].items()},
            java_sources={p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in sources},
            resources={p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in (ROOT / 'android/app/res').rglob('*') if p.is_file()},
            emulator_used=False, runtime_tested=False, work_directory=str(work))
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(work / 'signed.apk', output)
        output.with_suffix('.apk.sha256').write_text(report['apk_sha256'] + '  ' + output.name + '\n')
        output.with_suffix('.verification.json').write_text(json.dumps(report, indent=2) + '\n')
        print(f'APK: {output} ({report["apk_bytes"] / 1e6:.1f} MB)', flush=True)


if __name__ == '__main__':
    main()
