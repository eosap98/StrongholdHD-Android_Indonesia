"""Pinned upstream source snapshots: builds also work from ZIPs without .git."""
import hashlib
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BASE_COMMIT = 'ffe2e9722f5ab37a0b6a14af27f0e502af3996a0'
SNAPSHOT_ROOT = ROOT / 'build-support/baseline' / BASE_COMMIT
BASELINE_SHA256 = {'android/host/touch.c': '0f7d49ce8e45118563a1ea6f1e3ba0ee984ed16ad323fe10bd82e04e3166681d', 'android/host/game_ui.c': 'd3417b0cfa76efbd0882d0a5cf2f542e8ef0ad8c093a9ba3133435f84bb331b0', 'android/host/display.c': '71fa4459ac6456c0251ae9551d9b0ca182b8bafba142f53aa4321d081c3a0fda', 'android/host/stronghold_original.c': 'a9db53e6899cef12d1f9e39e4ceab989999c25c79dbb06811639e3b9e294110d', 'android/host/memory.c': 'e4b550f01b7f1c42fbced72ee359c3d6440470f80e1c6f227019b673bf3ee149', 'android/host/core.c': '47c07a7afd3363b62a95ae6ccddf1915f72ea81e6c652017b75b97eb43b376bd'}


def baseline_source(path):
    if path not in BASELINE_SHA256:
        raise ValueError('Unreviewed baseline source: '+path)
    snapshot = SNAPSHOT_ROOT / path
    if snapshot.is_file():
        data = snapshot.read_bytes()
    else:
        result = subprocess.run(['git', 'show', BASE_COMMIT+':'+path], cwd=ROOT,
                                capture_output=True)
        if result.returncode:
            raise ValueError('Missing baseline snapshot: '+str(snapshot))
        data = result.stdout
    if hashlib.sha256(data).hexdigest() != BASELINE_SHA256[path]:
        raise ValueError('Baseline source hash mismatch: '+path)
    return data.decode('utf-8')


def verify_all():
    for path in BASELINE_SHA256:
        baseline_source(path)
    return len(BASELINE_SHA256)
