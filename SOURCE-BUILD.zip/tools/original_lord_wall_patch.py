"""Pinned Stronghold lord/wall leaf trampoline; combined with the host patch segment.

prepare(image, clang, work) -> (objects, bindings, report)
apply(result, image, linked_symbols) -> (redirect_report, changed_range)
Call prepare after baseline symbol recovery, link its objects/bindings with the
existing patch payload, then apply before the unchanged-ranges audit.
"""
import hashlib
import io
import struct
from pathlib import Path
from elftools.dwarf.callframe import FDE
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
from scenario_native_patch import ROOT, flags, run, sha, branch, PC_RELATIVE, BASE_COMMIT
from baseline_sources import baseline_source

INPUT_SHA = "6ef43df580a8394189067711c2f90e9eb1146fd75dca81ada474e49c98da892d"
CONTEXT = 0x12B9F38
CONTEXT_SIZE = 68484
CONTEXT_SHA = "5374fafb3279e3eb221989bb779a8d6ac31bda6f9627d7773281f0a6d1b4aba8"
SITE = 0x12C6168
RESUME = 0x12C6580
FALLTHROUGH = 0x12C616C
ENTRY = "stronghold_original_lord_wall_entry"


def verify(image):
    if sha(image.data) != INPUT_SHA:
        raise ValueError("unsupported lord/wall library identity")
    # Bind guest42DB20 through the shipped dispatch entry and ELF relocation,
    # not a nearby byte pattern or an assumed historical layout.
    table = image.elf.get_section_by_name(".data.rel.ro")
    entry = 0x2A112E8
    off = image.offset(entry, 16)
    if image.data[off:off+8] != struct.pack("<Q", 0x42DB20):
        raise ValueError("lord/wall guest callback dispatch changed")
    rels = [r for r in image.elf.get_section_by_name(".rela.dyn").iter_relocations()
            if r["r_offset"] == entry+8]
    if len(rels) != 1 or rels[0]["r_info_type"] != 1027 or rels[0]["r_addend"] != CONTEXT:
        raise ValueError("lord/wall native callback relocation changed")
    bodies = [f for f in image.elf.get_dwarf_info().EH_CFI_entries()
              if isinstance(f, FDE) and f.header.initial_location == CONTEXT]
    if len(bodies) != 1 or bodies[0].header.address_range != CONTEXT_SIZE:
        raise ValueError("lord/wall native callback boundary changed")
    start = image.offset(CONTEXT, CONTEXT_SIZE)
    if sha(image.data[start:start+CONTEXT_SIZE]) != CONTEXT_SHA:
        raise ValueError("lord/wall callback body changed")
    at = image.offset(SITE, 4)
    word, = struct.unpack_from("<I", image.data, at)
    expected = 0x54000001 | (((RESUME-SITE)//4 & 0x7ffff) << 5)
    if word != expected:
        raise ValueError("lord/wall original conditional branch changed")
    # w3 is the live guest ESP, reloaded after4F8320; accepted leaf retains
    # original instructions setting the context, permission checks and queue.
    expected_leaf = bytes.fromhex("2b00805233008052")
    if image.data[image.offset(RESUME):image.offset(RESUME)+8] != expected_leaf:
        raise ValueError("lord/wall accepted leaf changed")
    return {"input_sha256": INPUT_SHA, "guest_callback": "0x42db20",
            "dispatch_va": hex(entry), "callback_va": hex(CONTEXT),
            "callback_size": CONTEXT_SIZE, "callback_sha256": CONTEXT_SHA,
            "site": hex(SITE), "before": image.data[at:at+4].hex(),
            "accepted_resume": hex(RESUME), "original_fallthrough": hex(FALLTHROUGH),
            "guest_sp_register": "w3", "guest_permission_offset": "0x14"}


def trampoline():
    lines = [".section .text."+ENTRY+', "ax", @progbits',
             ".p2align 2", ".global "+ENTRY, ".hidden "+ENTRY, ".type "+ENTRY+", %function",
             ENTRY+":", "sub sp, sp, #784"]
    for i in range(0, 30, 2):
        lines.append(f"stp x{i}, x{i+1}, [sp, #{i*8}]")
    lines += ["str x30, [sp, #240]", "mrs x9, nzcv", "str x9, [sp, #248]"]
    for i in range(0, 32, 2):
        lines.append(f"stp q{i}, q{i+1}, [sp, #{256+i*16}]")
    lines += ["mrs x9, fpcr", "str x9, [sp, #768]",
              "mrs x9, fpsr", "str x9, [sp, #776]",
              "mov w0, w3", "bl stronghold_original_lord_wall", "cbz w0, .Llord_original"]

    def restore():
        out = ["ldr x9, [sp, #768]", "msr fpcr, x9",
               "ldr x9, [sp, #776]", "msr fpsr, x9",
               "ldr x9, [sp, #248]", "msr nzcv, x9"]
        for i in range(0, 32, 2):
            out.append(f"ldp q{i}, q{i+1}, [sp, #{256+i*16}]")
        for i in range(0, 30, 2):
            out.append(f"ldp x{i}, x{i+1}, [sp, #{i*8}]")
        out += ["ldr x30, [sp, #240]", "add sp, sp, #784"]
        return out
    lines += restore() + ["b __lord_accepted", ".Llord_original:"]
    lines += restore() + ["b.eq .Llord_rejected", "b __lord_accepted",
                          ".Llord_rejected:", "b __lord_fallthrough",
                          ".size "+ENTRY+", .-"+ENTRY]
    return "\n".join(lines)+"\n"


def prepare(image, clang, work):
    record = verify(image)
    work = Path(work)
    memory_source = work/"lord_memory.baseline.c"
    memory_object = work/"lord_memory.baseline.o"
    memory_source.write_text(baseline_source('android/host/memory.c'))
    run(clang, *flags("stronghold"), "-c", memory_source, "-o", memory_object)
    memory_binding = image.recover(memory_object, "lord_memory", "void_vm_readable")
    cfile = ROOT/"android/host/original_lord_wall.c"
    helper = work/"original_lord_wall.o"
    opts = flags("stronghold")+["-ffunction-sections", "-fdata-sections",
        "-fno-stack-protector", "-fno-unwind-tables", "-fno-asynchronous-unwind-tables",
        "-Dvoid_vm_readable=stronghold_lord_vm_readable",
        "-Dvoid_vm_writable=stronghold_lord_vm_writable"]
    run(clang, *opts, "-c", cfile, "-o", helper)
    assembly = work/"original_lord_wall_entry.s"
    assembly.write_text(trampoline())
    stub = work/"original_lord_wall_entry.o"
    run(clang, "--target=aarch64-linux-android28", "-c", assembly, "-o", stub)
    bindings = {"__lord_accepted": RESUME, "__lord_fallthrough": FALLTHROUGH,
        "stronghold_lord_vm_readable": image.address("lord_memory", "void_vm_readable"),
        "stronghold_lord_vm_writable": image.address("lord_memory", "void_vm_writable")}
    # stronghold_touch_lord_control resolves to the replacement root in the
    # combined payload. Link failure is preferable to calling its old zero stub.
    for obj in (helper, stub):
        elf = ELFFile(io.BytesIO(obj.read_bytes()))
        for sec in elf.iter_sections():
            if isinstance(sec, RelocationSection):
                for rel in sec.iter_relocations():
                    if rel["r_info_type"] not in PC_RELATIVE:
                        raise ValueError("unsafe lord/wall relocation")
            elif sec["sh_flags"] & 3 == 3 and sec["sh_size"]:
                raise ValueError("lord/wall patch introduced mutable storage")
    record.update({"helper_source_sha256": sha(cfile.read_bytes()),
        "memory_binding": memory_binding,
        "trampoline_sha256": sha(assembly.read_bytes()),
        "objects": {p.name: sha(p.read_bytes()) for p in (helper, stub)},
        "preserved": ["x0-x30", "q0-q31", "SP", "NZCV", "FPCR", "FPSR"],
        "native_guard": "stronghold_touch_lord_control",
        "original_route_capacity_checks_preserved": True})
    return [helper, stub], bindings, record


def apply(result, image, symbols):
    record = verify(image)
    if ENTRY not in symbols or "stronghold_touch_lord_control" not in symbols:
        raise ValueError("lord/wall payload missing trampoline or native transaction guard")
    at = image.offset(SITE, 4)
    replacement = branch(SITE, symbols[ENTRY])
    result[at:at+4] = replacement
    record.update({"unit": "original_lord_wall", "function": ENTRY,
        "original_va": hex(SITE), "new_va": hex(symbols[ENTRY]),
        "offset": at, "after": replacement.hex()})
    return record, (at, at+4)

