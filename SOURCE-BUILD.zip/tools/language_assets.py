"""Import and verify the supplied Indonesian patches as deterministic APK assets."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'android/app/assets/language'
SOURCES = {
    'crusader': ('Patch Bahasa Indonesia - Crusader & Extreme HD', 'Stronghold Extreme HD', 'laporan/manifest_pemasangan.json'),
    'stronghold': ('Patch Bahasa Indonesia - Stronghold Classic HD', 'Stronghold Classic HD', 'manifest_pemasangan.json'),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def valid_name(name):
    return (bool(name) and '\\' not in name and not any(c in name for c in '\t\r\n:')
            and all(p not in ('', '.', '..') and not p.startswith('.') for p in name.split('/')))


def make_zip(family, files):
    manifest = 'stronghold-id-v1\t' + family + '\n' + ''.join(
        f'{digest(data)}\t{len(data)}\t{name}\n' for name, data in sorted(files.items()))
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in [('_manifest.tsv', manifest.encode()), *sorted(files.items())]:
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compresslevel=9)
    return stream.getvalue()


def import_patches(workspace, destination=ASSETS):
    catalog = {'format': 1, 'patches': {}}
    for family, (folder, game, manifest) in SOURCES.items():
        source = workspace / folder
        records = json.loads((source / manifest).read_text())['files']
        expected = {record['path']: record for record in records}
        paths = sorted(p for p in (source / game).rglob('*') if p.is_file())
        files = {p.relative_to(source / game).as_posix(): p.read_bytes() for p in paths}
        if files.keys() != expected.keys() or any(p.is_symlink() for p in paths):
            raise ValueError('Patch inventory differs from supplied manifest: ' + family)
        for name, data in files.items():
            if not valid_name(name) or digest(data) != expected[name]['output_sha256']:
                raise ValueError('Patch differs from supplied manifest: ' + name)
        data = make_zip(family, files)
        destination.mkdir(parents=True, exist_ok=True)
        (destination / (family + '.zip')).write_bytes(data)
        catalog['patches'][family] = {
            'sha256': digest(data), 'bytes': len(data), 'file_count': len(files),
            'source': folder + '/' + game,
            'files': {name: {'sha256': digest(blob), 'bytes': len(blob),
                             'original_sha256': expected[name].get('original_sha256')}
                      for name, blob in sorted(files.items())},
        }
    (destination / 'catalog.json').write_text(json.dumps(catalog, indent=2) + '\n')
    return catalog


def verify(directory=ASSETS):
    catalog = json.loads((directory / 'catalog.json').read_text())
    if catalog.get('format') != 1 or set(catalog.get('patches', {})) != set(SOURCES):
        raise ValueError('Invalid language asset catalog')
    assets = {}
    for family, record in catalog['patches'].items():
        path = directory / (family + '.zip')
        data = path.read_bytes()
        if digest(data) != record['sha256'] or len(data) != record['bytes']:
            raise ValueError('Language archive changed: ' + family)
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            names = archive.namelist()
            if (len(names) != len(set(names)) or names[0] != '_manifest.tsv'
                    or set(names[1:]) != set(record['files']) or len(names) != record['file_count'] + 1
                    or archive.testzip() is not None):
                raise ValueError('Invalid language archive inventory: ' + family)
            files = {name: archive.read(name) for name in names[1:]}
            for name, blob in files.items():
                expected = record['files'][name]
                if not valid_name(name) or digest(blob) != expected['sha256'] or len(blob) != expected['bytes']:
                    raise ValueError('Invalid language asset: ' + name)
            manifest = ('stronghold-id-v1\t' + family + '\n' + ''.join(
                f'{digest(blob)}\t{len(blob)}\t{name}\n' for name, blob in sorted(files.items()))).encode()
            if archive.read('_manifest.tsv') != manifest:
                raise ValueError('Runtime language manifest differs from catalog')
        assets['assets/language/' + path.name] = data
    java = (ROOT / 'android/app/src/org/stronghold/port/LanguagePatchFiles.java').read_text()
    for family, filename in (('crusader', 'Stronghold Crusader.exe'), ('crusader', 'Stronghold_Crusader_Extreme.exe'),
                             ('stronghold', 'Stronghold.exe')):
        entry = catalog['patches'][family]['files'][filename]
        if any(java.count('"' + entry[key] + '"') != 1 for key in ('sha256', 'original_sha256')):
            raise ValueError('Launcher accepted EXE hashes differ from the bundled patch: ' + filename)
    return assets, catalog


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--import-patches', type=Path)
    args = parser.parse_args()
    if args.import_patches:
        import_patches(args.import_patches)
    assets, catalog = verify()
    print(json.dumps({name: {'file_count': r['file_count'], 'zip_bytes': r['bytes'], 'sha256': r['sha256']}
                      for name, r in catalog['patches'].items()}, indent=2))
