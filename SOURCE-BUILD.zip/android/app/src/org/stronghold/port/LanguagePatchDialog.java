package org.stronghold.port;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceGroup;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/** Indonesian patch control shared by all three edition settings screens. */
final class LanguagePatchDialog {
    private static LanguagePatchFiles.Lease gameLease;
    private final PreferenceActivity activity;
    private final Preference item;
    private final String edition;
    private boolean busy;

    private LanguagePatchDialog(PreferenceActivity activity, PreferenceGroup home, String edition) {
        this.activity = activity;
        this.edition = edition;
        item = new Preference(activity);
        item.setKey("indonesian-language");
        item.setPersistent(false);
        item.setTitle("Aktifkan Bahasa Indonesia");
        home.addPreference(item);
        item.setOnPreferenceClickListener(preference -> { inspect(true); return true; });
        inspect(false);
    }

    static void addPreference(PreferenceActivity activity, PreferenceGroup home, String edition) {
        new LanguagePatchDialog(activity, home, edition);
    }

    private static File lockFile(Context context) { return new File(context.getFilesDir(), "language-game.lock"); }

    /** Called after file validation, before loading native code. The OS releases this lease at process exit. */
    static synchronized String guardGame(Activity activity, String priorError) {
        if (priorError != null) return priorError;
        if (gameLease != null) return null;
        LanguagePatchFiles.Lease lease = null;
        try {
            lease = new LanguagePatchFiles.Lease(lockFile(activity), true);
            String directory = activity.getIntent().getStringExtra("game");
            if (directory == null) directory = GameFiles.DEFAULT_GAME;
            String edition = ((GameActivity) activity).gameEdition();
            if (new LanguagePatchFiles(new File(directory), edition).interrupted())
                throw new IOException("Pemasangan bahasa belum selesai. Buka pengaturan edisi ini, lalu pulihkan bahasa sebelumnya.");
            gameLease = lease;
            return null;
        } catch (IOException | RuntimeException failure) {
            if (lease != null) try { lease.close(); } catch (IOException ignored) {}
            return "Game belum dapat dibuka. " + failure.getMessage();
        }
    }

    private File selectedFolder() {
        // Match LauncherActivity.savedPaths(), including the legacy Extreme fallback.
        SharedPreferences preferences = activity.getSharedPreferences("LauncherActivity", Context.MODE_PRIVATE | Context.MODE_MULTI_PROCESS);
        String[] paths = GameFiles.savedPaths(preferences.getString("game", null), preferences.getString("extremeGame", null),
                preferences.getString("strongholdGame", null));
        return new File(paths["stronghold".equals(edition) ? 2 : "extreme".equals(edition) ? 1 : 0]);
    }

    private boolean alive() { return !activity.isFinishing() && !activity.isDestroyed(); }

    private void inspect(boolean clicked) {
        if (busy) return;
        busy = true;
        item.setEnabled(false);
        File directory = selectedFolder();
        item.setSummary("Memeriksa bahasa…\n" + directory);
        new Thread(() -> {
            try {
                LanguagePatchFiles files = new LanguagePatchFiles(directory, edition);
                int state = files.state();
                activity.runOnUiThread(() -> {
                    busy = false;
                    if (!alive()) return;
                    item.setEnabled(true);
                    item.setTitle(state == 1 ? "Bahasa Indonesia aktif" : state == 2 ? "Perbaiki patch Bahasa Indonesia" : "Aktifkan Bahasa Indonesia");
                    item.setSummary((state == 1 ? "Ketuk untuk memasang ulang atau memulihkan bahasa sebelumnya."
                            : state == 2 ? "Berkas berubah atau pemasangan terputus. Ketuk untuk memulihkan cadangan."
                            : "Pasang terjemahan teks, gambar, dan EXE ke folder game. Cadangan dibuat otomatis. Nonaktifkan mod bahasa lain agar tidak menimpa terjemahan.")
                            + ("stronghold".equals(edition) ? "" : "\nCrusader dan Extreme memakai patch bersama jika foldernya sama.") + "\n" + directory);
                    if (!clicked) return;
                    if (state == 0) change(directory, false);
                    else new AlertDialog.Builder(activity).setTitle("Bahasa Indonesia · " + GameFiles.title(edition))
                            .setMessage("Folder game:\n" + directory + "\n\nCadangan disimpan di dalam folder game."
                                    + ("stronghold".equals(edition) ? "" : " Perubahan berlaku untuk Crusader dan Extreme dalam folder yang sama."))
                            .setPositiveButton(state == 1 ? "Pasang ulang" : "Perbaiki", (dialog, which) -> change(directory, false))
                            .setNeutralButton("Pulihkan bahasa sebelumnya", (dialog, which) -> change(directory, true))
                            .setNegativeButton("Tutup", null).show();
                });
            } catch (IOException | RuntimeException failure) {
                activity.runOnUiThread(() -> {
                    busy = false;
                    if (!alive()) return;
                    item.setEnabled(true);
                    item.setSummary("Pilih folder game yang dapat diakses di peluncur.\n" + directory);
                    if (clicked) showFailure(failure);
                });
            }
        }, "language-check").start();
    }

    private void change(File directory, boolean restore) {
        if (busy) return;
        busy = true;
        item.setEnabled(false);
        ProgressDialog progress = new ProgressDialog(activity);
        progress.setTitle(restore ? "Memulihkan bahasa sebelumnya" : "Memasang Bahasa Indonesia");
        progress.setMessage("Menyiapkan berkas…");
        progress.setIndeterminate(true);
        progress.setCancelable(false);
        progress.show();
        new Thread(() -> {
            Exception error = null;
            try (LanguagePatchFiles.Lease lease = new LanguagePatchFiles.Lease(lockFile(activity), false)) {
                LanguagePatchFiles files = new LanguagePatchFiles(directory, edition);
                LanguagePatchFiles.Progress update = message -> activity.runOnUiThread(() -> {
                    if (alive() && progress.isShowing()) progress.setMessage(message);
                });
                if (restore) files.restore(update);
                else {
                    if (files.interrupted()) files.restore(update);
                    GameFiles.Check check = GameFiles.check(directory, edition, true);
                    if (check.error != null) throw new IOException(check.error);
                    if (check.warning != null) throw new IOException("EXE game berbeda dari versi yang didukung patch.\n" + check.warning);
                    File images = GameFiles.images(directory, edition);
                    try (InputStream input = activity.getAssets().open("language/" + files.family + ".zip")) {
                        files.install(input, images, update);
                    }
                }
            } catch (IOException | RuntimeException failure) { error = failure; }
            final Exception result = error;
            activity.runOnUiThread(() -> {
                busy = false;
                if (!alive()) return;
                progress.dismiss();
                if (result != null) showFailure(result);
                else new AlertDialog.Builder(activity).setTitle(restore ? "Bahasa sebelumnya dipulihkan" : "Bahasa Indonesia aktif")
                        .setMessage((restore ? "Berkas game telah dipulihkan dari cadangan."
                                : "Patch telah dipasang dan diperiksa. Buka game dari peluncur untuk memakai Bahasa Indonesia.\n\nCadangan: "
                                    + new File(directory, LanguagePatchFiles.BACKUP)) + "\n\nFolder game: " + directory)
                        .setPositiveButton("Selesai", null).show();
                inspect(false);
            });
        }, "language-install").start();
    }

    private void showFailure(Exception failure) {
        String message = failure.getMessage();
        if (failure.getSuppressed().length > 0)
            message += "\nPemulihan otomatis belum selesai. Cadangan tetap disimpan; gunakan Pulihkan bahasa sebelumnya.";
        new AlertDialog.Builder(activity).setTitle("Bahasa belum dapat diubah")
                .setMessage(message == null ? failure.toString() : message).setPositiveButton("Tutup", null).show();
    }
}
