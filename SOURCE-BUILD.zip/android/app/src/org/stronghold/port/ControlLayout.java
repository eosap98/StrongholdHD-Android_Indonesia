package org.stronghold.port;

import java.util.Map;

/** Shared command placements; saved positions use fractions of the whole game view. */
final class ControlLayout {
    static final int SCREEN = 0, HIDDEN = 2, LEFT_ZONE = 3, RIGHT_ZONE = 4, BOOK_ZONE = 5;
    static final String[] IDS = {"menu", "pause", "text", "settings", "layout", "help", "switch",
            "ctrl", "shift", "backspace", "enter", "f5", "f1", "slower", "speed", "faster",
            "relief", "zoom", "rotate_left", "rotate_right", "hide_hud", "hide_walls", "editor", "lmb", "rmb", "groups", "markers",
            "editor_pause", "editor_resources", "editor_lord", "editor_type", "editor_animals", "editor_seams", "zoom_value", "gamepad_help"};
    static final String[] LABELS = {"Меню", "Пауза", "Ввод", "Настройки", "Расположение", "?", "Другая игра / лаунчер",
            "Ctrl", "Shift", "⌫", "Enter", "F5", "F1 · замок", "−", "Скорость игры", "+",
            "Рельеф", "Масштаб", "Putar kiri · X", "Putar kanan · C", "Tampilkan / sembunyikan HUD · TAB", "Tampilkan / sembunyikan tembok · V",
            "Действия редактора", "ЛКМ", "ПКМ", "Отряд", "Точки", "Editor: jeda", "Editor: pajak, uang, dan ransum", "Editor: pulihkan lord",
            "Editor: jenis peta", "Editor: hapus hewan", "Editor: sambungan medan", "Приближение карты", "Геймпад · раскладка"};
    static String label(String id) {
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return LABELS[i];
        throw new IllegalArgumentException(id);
    }
    static boolean known(String id) {
        for (String candidate : IDS) if (candidate.equals(id)) return true;
        return false;
    }
    static boolean inZone(String id) { return known(id) && !"speed".equals(id) && !"zoom_value".equals(id); }
    static int defaultPlacement(String id, boolean extra, boolean touchpad, boolean groups, boolean markers) {
        if (!known(id)) return HIDDEN;
        if (tapScan(id) != 0 || "gamepad_help".equals(id) || "editor".equals(id)) return SCREEN;
        if ("zoom_value".equals(id) || id.startsWith("editor_")) return HIDDEN;
        // Screen taps already left-click in cursor mode; an explicit choice can restore the button.
        if ("lmb".equals(id)) return HIDDEN;
        if ("rmb".equals(id)) return touchpad ? SCREEN : HIDDEN;
        if ("groups".equals(id)) return groups ? SCREEN : HIDDEN;
        if ("markers".equals(id)) return markers ? SCREEN : HIDDEN;
        if (!extra && ("layout".equals(id) || "menu".equals(id))) return BOOK_ZONE;
        return extra ? SCREEN : HIDDEN;
    }
    static int placement(String id, int saved, int fallback) {
        if (!known(id)) return HIDDEN;
        if (saved == 1) return HIDDEN; // Legacy command-menu placement must not revive a menu after updating.
        if (saved == SCREEN || saved == HIDDEN) return saved;
        return (saved == LEFT_ZONE || saved == RIGHT_ZONE || saved == BOOK_ZONE) && inZone(id) ? saved : fallback;
    }
    private static boolean flag(Map<String, ?> preferences, String key) { return Boolean.TRUE.equals(preferences.get(key)); }
    static int placement(Map<String, ?> preferences, String id) {
        int fallback = defaultPlacement(id, flag(preferences, "extra"), flag(preferences, "touchpad"),
                flag(preferences, "groupWheel"), flag(preferences, "markerWheel"));
        Object saved = preferences.get("control-" + id);
        return placement(id, saved instanceof Integer ? (Integer)saved : fallback, fallback);
    }
    private static String zonePrefix(int side) { return side == 0 ? "zone-left-" : side == 1 ? "zone-right-" : null; }
    static boolean zoneDirect(Map<String, ?> preferences, int side) {
        String prefix = zonePrefix(side);
        return prefix != null && "actions".equals(preferences.get(prefix + "mode"));
    }
    static String zoneAction(Map<String, ?> preferences, int side, boolean hold) {
        String prefix = zonePrefix(side);
        Object value = prefix == null ? null : preferences.get(prefix + (hold ? "hold" : "tap"));
        return value instanceof String && inZone((String)value) ? (String)value : "";
    }
    static boolean hasZoneActions(Map<String, ?> preferences, int side) {
        return zoneDirect(preferences, side) && (!zoneAction(preferences, side, false).isEmpty() || !zoneAction(preferences, side, true).isEmpty());
    }
    static boolean removedMenuKey(String key) {
        return key != null && (key.startsWith("radial-slot-") || "control-more".equals(key) ||
                "pos-more".equals(key) || key.startsWith("pos-more-"));
    }
    static boolean cleanRemovedMenu(Map<String, Object> preferences) {
        boolean changed = false;
        java.util.Iterator<String> keys = preferences.keySet().iterator();
        while (keys.hasNext()) {
            String key = keys.next();
            if (removedMenuKey(key)) { keys.remove(); changed = true; }
        }
        for (String id : IDS) {
            String key = "control-" + id;
            if (Integer.valueOf(1).equals(preferences.get(key))) { preferences.put(key, HIDDEN); changed = true; }
        }
        return changed;
    }
    static int scan(String id) {
        switch (id) {
            case "ctrl": return 0x1d;
            case "shift": return 0x2a;
            case "backspace": return 0x0e;
            case "enter": return 0x1c;
            case "f5": return 0x3f;
            case "f1": return 0x3b;
            case "slower": return 0x4a;
            case "faster": return 0x4e;
            default: return 0;
        }
    }

    /** Original single key pulses; these must not keep the key held down. */
    static int tapScan(String id) {
        switch (id) {
            case "rotate_left": return 0x2d;
            case "rotate_right": return 0x2e;
            case "hide_hud": return 0x0f;
            case "hide_walls": return 0x2f;
            default: return 0;
        }
    }

    static int editorKey(String id) {
        switch (id) {
            case "editor_pause": return 'H';
            case "editor_resources": return 0xde;
            case "editor_lord": return 'V';
            case "editor_type": return 0xbc;
            case "editor_animals": return 'E';
            case "editor_seams": return 'D';
            default: return 0;
        }
    }
}
