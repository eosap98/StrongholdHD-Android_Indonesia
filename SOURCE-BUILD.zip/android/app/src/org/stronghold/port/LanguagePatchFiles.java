package org.stronghold.port;

import java.io.*;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Transactional, directory-scoped installer. This class is also tested on the host JVM. */
final class LanguagePatchFiles {
    static final String BACKUP = ".stronghold-language-backup";
    static final String[] ORIGINAL_EXE = {
        "e7c7afb39653a45e2f66d5f5c17f075749e3637f4a2ef30de4c8aca24843e69a",
        "0c90204f7bf622b768cc1fd9ebc0ec5c6cf8e60ea84911c0fdc7ffcbb2119ba8",
        "8b581f48df4d14b65b596f3a34ca2ee37b388ed93e7b1e505cceb0b1dadbcede"
    };
    static final String[] INDONESIAN_EXE = {
        "df1c898e9e34283675eb36d3d92152f2d5557090d33f62e7ea609577106a6962",
        "7013511b3f4167497a6e56dd835c2c956a9ba3f52fa62d0c65ea7e281426bac1",
        "59a4d94a029b69f1a3fa186971ebb680a0c35615825dac760513814604793f30"
    };
    static final String[] DLLS = {"Mss32.dll", "binkw32.dll"};
    static final String[] DLL_HASHES = {
        "2a515199cc7a2e1ccd8d756efdaab07cedd5c3052309ef1c7499c2560e2097bd",
        "ee68dcf51e8e3b482f9fb5ef617f44a2d9e970d03f3ed21fe26d40cd63c57a48"
    };
    interface Progress { void update(String message) throws IOException; }
    final Path game, backup;
    final String family;

    LanguagePatchFiles(File directory, String edition) throws IOException {
        if (!directory.isAbsolute() || !directory.isDirectory())
            throw new IOException("Pilih folder game yang tersedia di peluncur terlebih dahulu.");
        game = directory.getCanonicalFile().toPath();
        family = family(edition);
        backup = safe(game, BACKUP);
    }

    static String family(String edition) {
        if ("stronghold".equals(edition)) return "stronghold";
        if ("classic".equals(edition) || "extreme".equals(edition)) return "crusader";
        throw new IllegalArgumentException("Edisi game tidak dikenal.");
    }

    /** Preserve every original check; accept only the three exact translated EXE hashes. */
    static boolean matchesExecutable(String actual, Object expected) {
        if (actual.equals(expected)) return true;
        for (int i = 0; i < ORIGINAL_EXE.length; i++)
            if (ORIGINAL_EXE[i].equals(expected) && INDONESIAN_EXE[i].equals(actual)) return true;
        return false;
    }

    static boolean indonesianText(String name, String digest) {
        return ("cr.tex".equalsIgnoreCase(name) && "d8827350024a3513e7e2af5b1e2edde16edc677aa8637cc1553d5fb89188148a".equals(digest)) ||
                ("sh.tex".equalsIgnoreCase(name) && "35be7c26cafaa2eda2571865704f8cb853e7a805c7b322245f0a4e4c5fbc83c3".equals(digest));
    }

    /** One app-private lock coordinates every edition process, including a game starting mid-install. */
    static final class Lease implements AutoCloseable {
        private static final Set<String> held = new HashSet<>();
        final RandomAccessFile file;
        final FileLock lock;
        final String key;
        private boolean closed;
        Lease(File path, boolean shared) throws IOException {
            key = path.getCanonicalPath();
            synchronized (Lease.class) {
                // POSIX locks can be released when ANY descriptor for the same inode closes.
                // Reject a same-process overlap before opening a second descriptor.
                if (held.contains(key)) throw new IOException("Tutup game sebelum mengubah bahasa, atau tunggu pemasangan selesai.");
                file = new RandomAccessFile(path, "rw");
                FileLock acquired;
                try {
                    acquired = file.getChannel().tryLock(0, Long.MAX_VALUE, shared);
                    if (acquired == null) throw new IOException("Tutup semua game sebelum mengubah bahasa. Pemasangan lain juga harus selesai.");
                } catch (IOException | RuntimeException failure) {
                    file.close();
                    if (failure instanceof OverlappingFileLockException)
                        throw new IOException("Tutup game sebelum mengubah bahasa.", failure);
                    throw failure;
                }
                lock = acquired;
                held.add(key);
            }
        }
        public void close() throws IOException {
            synchronized (Lease.class) {
                if (closed) return;
                try { lock.release(); } finally {
                    try { file.close(); } finally { held.remove(key); closed = true; }
                }
            }
        }
    }

    // 0 = no patch, 1 = installed and verified, 2 = interrupted or changed on disk.
    int state() throws IOException {
        if (!Files.exists(safe(backup, "originals.tsv"))) return 0;
        Path active = safe(backup, "active.tsv");
        if (!Files.isRegularFile(active)) return 2;
        Map<String, String> installed = readJournal(active);
        for (Map.Entry<String, String> entry : installed.entrySet()) {
            Path path = safe(game, entry.getKey());
            if (!Files.isRegularFile(path) || !entry.getValue().equals(hash(path))) return 2;
        }
        return 1;
    }

    boolean interrupted() throws IOException {
        return Files.exists(safe(backup, "originals.tsv")) && !Files.exists(safe(backup, "active.tsv"));
    }

    void install(InputStream input, File images, Progress progress) throws IOException {
        // A complete old journal always wins over a new attempt after process death.
        if (interrupted()) restore(progress);
        Files.createDirectories(backup);
        Path stage = safe(backup, "stage");
        removeTree(stage);
        Files.createDirectories(stage);
        LinkedHashMap<String, String> installed = new LinkedHashMap<>();
        try {
            unpack(input, stage, installed, progress);
            for (int i = 0; i < DLLS.length; i++) {
                Path destination = safe(game, DLLS[i]);
                if (Files.exists(destination)) {
                    if (!DLL_HASHES[i].equals(hash(destination))) throw new IOException("Versi DLL tidak didukung: " + DLLS[i]);
                    continue;
                }
                Path source = images.toPath().resolve(DLLS[i]);
                if (!DLL_HASHES[i].equals(hash(source))) throw new IOException("DLL game tidak tersedia atau berbeda: " + DLLS[i]);
                copy(source, safe(stage, DLLS[i]));
                installed.put(DLLS[i], DLL_HASHES[i]);
            }
            // Preflight every destination before creating a journal or replacing any file.
            for (String name : installed.keySet()) {
                Path destination = safe(game, name);
                if (Files.exists(destination) && !Files.isRegularFile(destination))
                    throw new IOException("Tujuan bukan berkas: " + name);
            }
            Path journal = safe(backup, "originals.tsv");
            if (!Files.exists(journal)) {
                LinkedHashMap<String, String> originals = new LinkedHashMap<>();
                for (String name : installed.keySet()) {
                    progress.update("Mencadangkan " + name);
                    Path path = safe(game, name);
                    String digest = "-";
                    if (Files.exists(path)) {
                        digest = hash(path);
                        Path saved = safe(backup, "original/" + name);
                        copy(path, saved);
                        if (!digest.equals(hash(saved))) throw new IOException("Cadangan gagal diverifikasi: " + name);
                    }
                    originals.put(name, digest);
                }
                writeJournal(journal, originals);
            } else {
                Map<String, String> originals = readJournal(journal);
                if (!originals.keySet().containsAll(installed.keySet()))
                    throw new IOException("Pulihkan bahasa sebelumnya sebelum memasang paket yang berbeda.");
                verifyBackups(originals);
                // Include DLLs originally added by us, even when they now exist in the game folder.
                Map<String, String> previous = readJournal(safe(backup, "active.tsv"));
                for (String dll : DLLS) if (previous.containsKey(dll)) installed.put(dll, previous.get(dll));
            }
            Files.deleteIfExists(safe(backup, "active.tsv"));
            try {
                for (String name : installed.keySet()) {
                    progress.update("Memasang " + name);
                    Path source = safe(stage, name);
                    if (Files.exists(source)) replace(source, safe(game, name));
                    if (!installed.get(name).equals(hash(safe(game, name)))) throw new IOException("Hasil patch berbeda: " + name);
                }
                writeJournal(safe(backup, "active.tsv"), installed);
            } catch (IOException | RuntimeException failure) {
                try { restore(message -> {}); }
                catch (IOException recovery) { failure.addSuppressed(recovery); }
                throw failure;
            }
        } finally { removeTree(stage); }
    }

    void restore(Progress progress) throws IOException {
        Path journal = safe(backup, "originals.tsv");
        if (!Files.exists(journal)) throw new IOException("Cadangan bahasa sebelumnya tidak ditemukan.");
        Map<String, String> originals = readJournal(journal);
        verifyBackups(originals); // A damaged backup must not cause a partial restore.
        for (String name : originals.keySet()) safe(game, name);
        Files.deleteIfExists(safe(backup, "active.tsv"));
        for (Map.Entry<String, String> entry : originals.entrySet()) {
            progress.update("Memulihkan " + entry.getKey());
            Path destination = safe(game, entry.getKey());
            if ("-".equals(entry.getValue())) Files.deleteIfExists(destination);
            else replace(safe(backup, "original/" + entry.getKey()), destination);
        }
        // Remove the journal only after every original is restored. Interrupted restores can retry.
        Files.delete(journal);
        removeTree(backup);
    }

    private void verifyBackups(Map<String, String> originals) throws IOException {
        for (Map.Entry<String, String> entry : originals.entrySet())
            if (!"-".equals(entry.getValue()) && !entry.getValue().equals(hash(safe(backup, "original/" + entry.getKey()))))
                throw new IOException("Cadangan rusak atau hilang: " + entry.getKey());
    }

    private void unpack(InputStream input, Path stage, LinkedHashMap<String, String> installed, Progress progress) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(input))) {
            ZipEntry entry = zip.getNextEntry();
            if (entry == null || !"_manifest.tsv".equals(entry.getName())) throw new IOException("Manifest patch tidak ditemukan.");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            transfer(zip, bytes, 256 * 1024);
            String[] lines = new String(bytes.toByteArray(), StandardCharsets.UTF_8).split("\n");
            if (lines.length < 2 || !("stronghold-id-v1\t" + family).equals(lines[0])) throw new IOException("Paket patch bukan untuk edisi ini.");
            Map<String, Long> sizes = new LinkedHashMap<>();
            long total = 0;
            for (int i = 1; i < lines.length; i++) {
                String[] fields = lines[i].split("\t", -1);
                if (fields.length != 3 || !fields[0].matches("[0-9a-f]{64}")) throw new IOException("Manifest patch rusak.");
                targetName(fields[2]);
                safe(stage, fields[2]);
                long size;
                try { size = Long.parseLong(fields[1]); } catch (NumberFormatException invalid) { throw new IOException("Ukuran patch tidak valid.", invalid); }
                if (size < 0 || size > 64 * 1024 * 1024 || (total += size) > 128 * 1024 * 1024 || sizes.size() >= 1024
                        || sizes.put(fields[2], size) != null) throw new IOException("Isi paket patch tidak valid.");
                installed.put(fields[2], fields[0]);
            }
            Set<String> seen = new HashSet<>();
            while ((entry = zip.getNextEntry()) != null) {
                String name = entry.getName();
                if (entry.isDirectory() || !sizes.containsKey(name) || !seen.add(name)) throw new IOException("Berkas patch tidak dikenal: " + name);
                progress.update("Memeriksa " + name);
                Path output = safe(stage, name);
                Files.createDirectories(output.getParent());
                try (FileOutputStream stream = new FileOutputStream(output.toFile())) {
                    if (transfer(zip, stream, sizes.get(name)) != sizes.get(name)) throw new IOException("Berkas patch terpotong: " + name);
                    stream.getFD().sync();
                }
                if (!installed.get(name).equals(hash(output))) throw new IOException("Checksum patch salah: " + name);
            }
            if (!seen.equals(sizes.keySet())) throw new IOException("Paket patch tidak lengkap.");
        }
    }

    private Map<String, String> readJournal(Path path) throws IOException {
        if (Files.size(path) > 256 * 1024) throw new IOException("Catatan patch terlalu besar.");
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        if (lines.size() < 2 || !("stronghold-id-v1\t" + family).equals(lines.get(0))) throw new IOException("Cadangan berasal dari edisi berbeda atau rusak.");
        Map<String, String> result = new LinkedHashMap<>();
        for (int i = 1; i < lines.size(); i++) {
            String[] fields = lines.get(i).split("\t", -1);
            if (fields.length != 2 || !fields[0].matches("-|[0-9a-f]{64}")) throw new IOException("Catatan cadangan rusak.");
            targetName(fields[1]);
            safe(game, fields[1]);
            if (result.put(fields[1], fields[0]) != null) throw new IOException("Catatan cadangan ganda.");
        }
        return result;
    }

    private void writeJournal(Path path, Map<String, String> entries) throws IOException {
        StringBuilder text = new StringBuilder("stronghold-id-v1\t" + family + "\n");
        for (Map.Entry<String, String> entry : entries.entrySet()) text.append(entry.getValue()).append('\t').append(entry.getKey()).append('\n');
        Path temp = safe(backup, "journal.tmp");
        try (FileOutputStream stream = new FileOutputStream(temp.toFile())) {
            stream.write(text.toString().getBytes(StandardCharsets.UTF_8)); stream.getFD().sync();
        }
        move(temp, path);
    }

    static Path safe(Path root, String name) throws IOException {
        if (name.isEmpty() || name.startsWith("/") || name.contains("\\") || name.matches(".*[\t\r\n:].*")) throw new IOException("Nama berkas tidak aman.");
        Path result = root;
        if (Files.isSymbolicLink(root)) throw new IOException("Folder patch tidak boleh berupa tautan.");
        for (String part : name.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) throw new IOException("Jalur patch tidak aman.");
            result = result.resolve(part);
            if (Files.isSymbolicLink(result)) throw new IOException("Berkas patch tidak boleh melalui tautan: " + name);
        }
        return result;
    }

    private static void targetName(String name) throws IOException {
        String top = name.split("/", -1)[0];
        if (!Arrays.asList("BAHASA_INDONESIA.txt", "Stronghold Crusader.exe", "Stronghold_Crusader_Extreme.exe", "Stronghold.exe",
                "cr.tex", "sh.tex", "stronghold.mlb", "EULA.txt", "EULA_en.txt", "EULA_id.txt", "goggame-1207658713.info",
                "Mss32.dll", "binkw32.dll", "gfx", "gm", "help", "images", "manual").contains(top))
            throw new IOException("Berkas di luar cakupan patch: " + name);
    }

    static String hash(Path path) throws IOException {
        MessageDigest digest;
        try { digest = MessageDigest.getInstance("SHA-256"); } catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
        try (InputStream input = Files.newInputStream(path)) {
            byte[] buffer = new byte[65536]; int count;
            while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
        }
        StringBuilder result = new StringBuilder();
        for (byte value : digest.digest()) result.append(String.format(Locale.ROOT, "%02x", value & 255));
        return result.toString();
    }

    private static long transfer(InputStream input, OutputStream output, long limit) throws IOException {
        byte[] buffer = new byte[65536]; int count; long size = 0;
        while ((count = input.read(buffer)) != -1) {
            if ((size += count) > limit) throw new IOException("Berkas patch melebihi ukuran manifest.");
            output.write(buffer, 0, count);
        }
        return size;
    }

    private static void copy(Path source, Path destination) throws IOException {
        Files.createDirectories(destination.getParent());
        try (InputStream input = Files.newInputStream(source); FileOutputStream output = new FileOutputStream(destination.toFile())) {
            transfer(input, output, 128 * 1024 * 1024); output.getFD().sync();
        }
    }

    private static void replace(Path source, Path destination) throws IOException {
        Files.createDirectories(destination.getParent());
        Path temp = Files.createTempFile(destination.getParent(), ".stronghold-id-", ".tmp");
        try { copy(source, temp); move(temp, destination); } finally { Files.deleteIfExists(temp); }
    }

    private static void move(Path source, Path destination) throws IOException {
        try { Files.move(source, destination, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException unsupported) { Files.move(source, destination, StandardCopyOption.REPLACE_EXISTING); }
    }

    private static void removeTree(Path path) throws IOException {
        if (Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) {
            try (DirectoryStream<Path> children = Files.newDirectoryStream(path)) {
                for (Path child : children) removeTree(child);
            }
        }
        Files.deleteIfExists(path);
    }
}
