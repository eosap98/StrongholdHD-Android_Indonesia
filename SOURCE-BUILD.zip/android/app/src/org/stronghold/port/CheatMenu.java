package org.stronghold.port;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The two-key collapsible panel supplied by the previous Stronghold launcher. */
final class CheatMenu extends FrameLayout {
    interface Listener { void press(char key); }
    private static final char[] KEYS = {'X', 'Q'};
    private final LinearLayout panel;
    private final FrameLayout handle;
    private boolean collapsed, inGame, suppressed;

    CheatMenu(Context context, Listener listener) {
        super(context);
        setClipChildren(false); setClipToPadding(false);
        panel = new LinearLayout(context); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(7), dp(6), dp(7), dp(7));
        panel.setBackground(glass(new int[]{0xb82b4052, 0x94182836, 0xb51d2a38}, 15));
        panel.setElevation(dp(12));
        LinearLayout title = new LinearLayout(context); title.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text("Cheat", 12); heading.setGravity(Gravity.CENTER_VERTICAL); heading.setPadding(dp(5), 0, 0, 0);
        title.addView(heading, new LinearLayout.LayoutParams(-2, dp(28), 1));
        FrameLayout close = dot("Sembunyikan menu cheat");
        close.setOnClickListener(v -> { collapsed = true; refresh(); }); pressFeedback(close);
        LinearLayout.LayoutParams closeSize = new LinearLayout.LayoutParams(dp(28), dp(28)); closeSize.leftMargin = dp(6);
        title.addView(close, closeSize); panel.addView(title);
        LinearLayout row = new LinearLayout(context); row.setGravity(Gravity.LEFT);
        for (char key : KEYS) {
            TextView button = text(Character.toString(key), 15); button.setGravity(Gravity.CENTER);
            button.setContentDescription("Cheat Alt+" + key);
            button.setBackground(glass(new int[]{0x8a587185, 0x66324758}, 10));
            button.setOnClickListener(v -> { if (inGame && !suppressed) listener.press(key); }); pressFeedback(button);
            LinearLayout.LayoutParams size = new LinearLayout.LayoutParams(dp(36), dp(36));
            size.setMargins(dp(2), dp(2), dp(2), dp(2)); row.addView(button, size);
        }
        panel.addView(row); addView(panel, new FrameLayout.LayoutParams(-2, -2));
        handle = dot("Tampilkan menu cheat");
        handle.setOnClickListener(v -> { collapsed = false; refresh(); }); pressFeedback(handle);
        addView(handle, new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.TOP | Gravity.RIGHT));
        refresh();
    }

    void setState(boolean active, boolean hidden) {
        if (active && !inGame) collapsed = false;
        if (active == inGame && hidden == suppressed) return;
        inGame = active; suppressed = hidden; refresh();
    }
    private void refresh() {
        if (!inGame || suppressed) { setVisibility(GONE); return; }
        setVisibility(VISIBLE); panel.setVisibility(collapsed ? GONE : VISIBLE); handle.setVisibility(collapsed ? VISIBLE : GONE);
        requestLayout();
    }
    private int dp(float value) { return Theme.dp(getContext(), value); }
    private TextView text(String label, float size) {
        TextView view = new TextView(getContext()); view.setText(label); view.setTextColor(0xffffffff);
        view.setTextSize(size); view.setTypeface(Typeface.DEFAULT_BOLD); view.setSingleLine(true); return view;
    }
    private GradientDrawable glass(int[] colors, float radius) {
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        shape.setCornerRadius(dp(radius)); shape.setStroke(Math.max(1, dp(1)), 0x78ffffff); return shape;
    }
    private FrameLayout dot(String description) {
        FrameLayout view = new FrameLayout(getContext()); view.setContentDescription(description); view.setFocusable(true);
        View center = new View(getContext());
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xffe8f4ff, 0xff9cb7cd});
        shape.setShape(GradientDrawable.OVAL); shape.setStroke(Math.max(1, dp(1)), 0xff536c80);
        center.setBackground(shape); center.setElevation(dp(2));
        view.addView(center, new FrameLayout.LayoutParams(dp(12), dp(12), Gravity.CENTER)); return view;
    }
    private void pressFeedback(View view) {
        view.setOnTouchListener((target, event) -> {
            boolean pressed = event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_MOVE;
            target.setAlpha(pressed ? .7f : 1f);
            return false;
        });
    }
}
