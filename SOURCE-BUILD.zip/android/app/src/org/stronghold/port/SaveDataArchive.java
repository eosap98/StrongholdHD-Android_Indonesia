package org.stronghold.port;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

/** Compatible with the version-1 save archives shipped by the previous launcher. */
final class SaveDataArchive {
    static final String MARKER = "stronghold-save-backup.txt";
    static final byte[] FORMAT = "Stronghold save backup\nversion=1\n".getBytes(StandardCharsets.US_ASCII);
    static final String[] ROOTS = {"userdata-classic/Documents/Stronghold Crusader/",
            "userdata/Documents/Stronghold Crusader/", "userdata-stronghold/Documents/Stronghold/"};
    static final long MAX_FILE = 128L << 20, MAX_TOTAL = 4L << 30, MAX_ZIP = 2L << 30;
    static final int MAX_FILES = 20000;
    interface Progress { void update(long bytes, int files) throws IOException; }
    static final Progress SILENT = (bytes, files) -> {};

    static final class Entry {
        final String name;
        final long size, modified;
        Entry(String name, long size, long modified) { this.name = name; this.size = size; this.modified = modified; }
    }
    static final class Plan implements AutoCloseable {
        final File work;
        final List<Entry> entries;
        final long bytes;
        Plan(File work, List<Entry> entries, long bytes) {
            this.work = work; this.entries = Collections.unmodifiableList(entries); this.bytes = bytes;
        }
        int conflicts(File base) throws IOException {
            int count = 0;
            for (Entry entry : entries) if (safeFile(base, entry.name).isFile()) count++;
            return count;
        }
        public void close() throws IOException { removeTree(work.toPath()); }
    }
    static final class Imported {
        final int files;
        final File backup;
        Imported(int files, File backup) { this.files = files; this.backup = backup; }
    }

    static boolean allowed(String name) {
        if (name.length() > 512 || name.indexOf('\\') >= 0 || name.indexOf(':') >= 0) return false;
        for (String part : name.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) return false;
            for (int i = 0; i < part.length(); i++) if (Character.isISOControl(part.charAt(i))) return false;
        }
        boolean profile = false;
        for (String root : ROOTS) if (name.startsWith(root)) profile = true;
        String lower = name.toLowerCase(Locale.ROOT);
        return profile && (lower.endsWith(".sav") || lower.endsWith(".msv") || lower.endsWith(".cfg"));
    }

    /** Resolve the /sdcard base alias, but never follow links inside a profile. */
    static File safeFile(File base, String name) throws IOException {
        Path path = base.getCanonicalFile().toPath();
        if (name.isEmpty() || name.startsWith("/") || name.indexOf('\\') >= 0 || name.indexOf(':') >= 0)
            throw new IOException("Jalur save tidak valid: " + name);
        for (String part : name.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) throw new IOException("Jalur save tidak valid: " + name);
            Path match = null;
            if (Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) {
                try (DirectoryStream<Path> children = Files.newDirectoryStream(path)) {
                    for (Path child : children) if (part.equalsIgnoreCase(child.getFileName().toString())) {
                        if (match != null) throw new IOException("Nama folder atau save ganda: " + path.resolve(part));
                        match = child;
                    }
                }
            } else if (Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
                throw new IOException("Folder save tidak valid: " + path);
            }
            path = match == null ? path.resolve(part) : match;
            if (Files.isSymbolicLink(path)) throw new IOException("Jalur save berupa tautan: " + name);
        }
        return path.toFile();
    }

    private static List<Entry> inventory(File base) throws IOException {
        List<Entry> entries = new ArrayList<>();
        long total = 0;
        for (String root : ROOTS) {
            File folder = safeFile(base, root.substring(0, root.length() - 1));
            if (!folder.exists()) continue;
            if (!folder.isDirectory()) throw new IOException("Folder profil tidak valid: " + folder);
            ArrayDeque<File> pending = new ArrayDeque<>(); pending.add(folder);
            int visited = 0;
            while (!pending.isEmpty()) {
                File current = pending.removeFirst();
                if (++visited > MAX_FILES) throw new IOException("Terlalu banyak folder profil.");
                File[] children = current.listFiles();
                if (children == null) throw new IOException("Folder profil tidak dapat dibaca: " + current);
                for (File child : children) {
                    BasicFileAttributes a = Files.readAttributes(child.toPath(), BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
                    if (a.isSymbolicLink()) throw new IOException("Profil berisi tautan: " + child);
                    if (a.isDirectory()) { pending.add(child); continue; }
                    String name = root + folder.toPath().relativize(child.toPath()).toString().replace(File.separatorChar, '/');
                    if (!a.isRegularFile() || !allowed(name)) continue;
                    safeFile(base, name);
                    if (a.size() > MAX_FILE || (total += a.size()) > MAX_TOTAL || entries.size() >= MAX_FILES)
                        throw new IOException("Save data melebihi batas arsip.");
                    entries.add(new Entry(name, a.size(), a.lastModifiedTime().toMillis()));
                }
            }
        }
        entries.sort(Comparator.comparing(e -> e.name));
        return entries;
    }

    static int backup(File base, OutputStream output, Progress progress) throws IOException {
        return backup(base, output, progress, false);
    }
    private static int backup(File base, OutputStream output, Progress progress, boolean allowEmpty) throws IOException {
        List<Entry> entries = inventory(base);
        if (entries.isEmpty() && !allowEmpty) throw new IOException("Belum ada simpanan untuk dicadangkan.");
        long bytes = 0; int count = 0;
        try (ZipOutputStream zip = new ZipOutputStream(output)) {
            zip.putNextEntry(new ZipEntry(MARKER)); zip.write(FORMAT); zip.closeEntry();
            for (Entry entry : entries) {
                progress.update(bytes, count);
                File source = safeFile(base, entry.name);
                ZipEntry item = new ZipEntry(entry.name); item.setTime(entry.modified);
                zip.putNextEntry(item);
                long copied;
                try (InputStream input = new BufferedInputStream(new FileInputStream(source))) {
                    copied = copy(input, zip, entry.size, bytes, count, progress);
                }
                if (copied != entry.size || source.length() != entry.size || source.lastModified() != entry.modified)
                    throw new IOException("Simpanan berubah saat dicadangkan: " + entry.name);
                zip.closeEntry(); bytes += copied; progress.update(bytes, ++count);
            }
        }
        return count;
    }

    static Plan prepare(InputStream input, File cache, Progress progress) throws IOException {
        Files.createDirectories(cache.toPath());
        File work = Files.createTempDirectory(cache.toPath(), "save-import-").toFile();
        boolean complete = false;
        try {
            File archive = new File(work, "archive.zip");
            try (FileOutputStream output = new FileOutputStream(archive)) {
                copy(input, output, MAX_ZIP, 0, 0, progress); output.getFD().sync();
            }
            List<Entry> entries = new ArrayList<>(); Set<String> names = new HashSet<>();
            boolean marker = false; long bytes = 0; int count = 0;
            try (ZipFile zip = new ZipFile(archive)) {
                Enumeration<? extends ZipEntry> items = zip.entries();
                while (items.hasMoreElements()) {
                    ZipEntry entry = items.nextElement(); String name = entry.getName();
                    if (++count > MAX_FILES + 1) throw new IOException("Terlalu banyak isi arsip.");
                    if (!names.add(name.toLowerCase(Locale.ROOT))) throw new IOException("Nama berkas ganda dalam arsip: " + name);
                    if (name.equals(MARKER)) {
                        if (entry.getSize() != FORMAT.length) throw new IOException("Format cadangan tidak didukung.");
                        ByteArrayOutputStream data = new ByteArrayOutputStream();
                        try (InputStream content = zip.getInputStream(entry)) { copy(content, data, FORMAT.length, 0, 0, SILENT); }
                        if (!Arrays.equals(data.toByteArray(), FORMAT)) throw new IOException("Format cadangan tidak didukung.");
                        marker = true; continue;
                    }
                    if (entry.isDirectory() || !allowed(name) || entry.getSize() < 0 || entry.getSize() > MAX_FILE)
                        throw new IOException("Isi cadangan tidak valid: " + name);
                    if (entry.getSize() > MAX_TOTAL - bytes) throw new IOException("Isi cadangan terlalu besar.");
                    File target = safeFile(new File(work, "new"), name);
                    Files.createDirectories(target.getParentFile().toPath());
                    CRC32 crc = new CRC32(); long copied;
                    try (InputStream content = new CheckedInputStream(zip.getInputStream(entry), crc);
                         FileOutputStream output = new FileOutputStream(target)) {
                        copied = copy(content, output, entry.getSize(), bytes, entries.size(), progress); output.getFD().sync();
                    }
                    if (copied != entry.getSize() || crc.getValue() != entry.getCrc()) throw new IOException("Cadangan rusak: " + name);
                    if (entry.getTime() >= 0) Files.setLastModifiedTime(target.toPath(), java.nio.file.attribute.FileTime.fromMillis(entry.getTime()));
                    entries.add(new Entry(name, copied, entry.getTime())); bytes += copied;
                }
            }
            if (!marker || entries.isEmpty()) throw new IOException("Pilih ZIP dari fitur Cadangkan save data yang berisi simpanan/profil.");
            complete = true; return new Plan(work, entries, bytes);
        } finally { if (!complete) removeTree(work.toPath()); }
    }

    static Imported apply(Plan plan, File base, File backups, Progress progress) throws IOException {
        Set<String> existing = new HashSet<>();
        for (Entry entry : plan.entries) {
            File target = safeFile(base, entry.name);
            if (target.exists()) {
                if (!target.isFile()) throw new IOException("Tujuan simpanan bukan berkas: " + target);
                copyFile(target, safeFile(new File(plan.work, "old"), entry.name), SILENT);
                existing.add(entry.name);
            }
        }
        // Publish a complete recovery ZIP before touching any live save or profile.
        if (Files.isSymbolicLink(backups.toPath())) throw new IOException("Folder cadangan tidak boleh berupa tautan.");
        Files.createDirectories(backups.toPath());
        String stamp = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.ROOT).format(new Date());
        File saved = new File(backups, "Before Import " + stamp + "-" + UUID.randomUUID().toString().substring(0, 8) + ".zip");
        File partial = new File(saved + ".partial");
        try {
            try (OutputStream output = new FileOutputStream(partial)) { backup(base, output, progress, true); }
            try (FileOutputStream sync = new FileOutputStream(partial, true)) { sync.getFD().sync(); }
            Files.move(partial.toPath(), saved.toPath());
        } finally { Files.deleteIfExists(partial.toPath()); }
        List<Entry> changed = new ArrayList<>(); long bytes = 0;
        try {
            for (Entry entry : plan.entries) {
                progress.update(bytes, changed.size());
                File source = safeFile(new File(plan.work, "new"), entry.name);
                if (!source.isFile() || source.length() != entry.size) throw new IOException("Berkas impor berubah: " + entry.name);
                changed.add(entry);
                replace(source, safeFile(base, entry.name));
                bytes += entry.size; progress.update(bytes, changed.size());
            }
            return new Imported(changed.size(), saved);
        } catch (IOException | RuntimeException failure) {
            IOException rollback = null;
            Collections.reverse(changed);
            for (Entry entry : changed) try {
                File target = safeFile(base, entry.name);
                if (existing.contains(entry.name)) replace(safeFile(new File(plan.work, "old"), entry.name), target);
                else Files.deleteIfExists(target.toPath());
            } catch (IOException problem) { if (rollback == null) rollback = problem; else rollback.addSuppressed(problem); }
            IOException result = new IOException("Impor gagal. " + (rollback == null ? "Perubahan dibatalkan." : "Pemulihan belum lengkap.")
                    + " Cadangan sebelumnya: " + saved, failure);
            if (rollback != null) result.addSuppressed(rollback);
            throw result;
        }
    }

    private static void replace(File source, File target) throws IOException {
        Files.createDirectories(target.getParentFile().toPath());
        Path temp = Files.createTempFile(target.getParentFile().toPath(), ".stronghold-import-", ".tmp");
        try {
            copyFile(source, temp.toFile(), SILENT);
            try { Files.move(temp, target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(temp, target.toPath(), StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
    }
    private static void copyFile(File source, File target, Progress progress) throws IOException {
        Files.createDirectories(target.getParentFile().toPath());
        long size = source.length();
        try (InputStream input = new BufferedInputStream(new FileInputStream(source)); FileOutputStream output = new FileOutputStream(target)) {
            if (copy(input, output, size, 0, 0, progress) != size) throw new IOException("Berkas berubah saat disalin: " + source);
            output.getFD().sync();
        }
        Files.setLastModifiedTime(target.toPath(), Files.getLastModifiedTime(source.toPath()));
    }
    private static long copy(InputStream input, OutputStream output, long limit, long before, int files, Progress progress) throws IOException {
        byte[] buffer = new byte[65536]; long copied = 0;
        for (int n; (n = input.read(buffer)) != -1;) {
            copied += n;
            if (copied > limit) throw new IOException("Ukuran berkas melebihi batas cadangan.");
            output.write(buffer, 0, n); progress.update(before + copied, files);
        }
        return copied;
    }
    static void removeTree(Path root) throws IOException {
        if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) return;
        try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
            for (Path path : (Iterable<Path>) paths.sorted(Comparator.reverseOrder())::iterator) Files.delete(path);
        }
    }
}
