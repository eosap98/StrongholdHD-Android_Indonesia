package org.stronghold.port;

import android.app.AlertDialog;
import android.os.Environment;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceGroup;
import android.text.InputType;
import android.text.format.Formatter;
import android.widget.EditText;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.nio.file.NoSuchFileException;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

/** Save manager shared by the three settings screens, in their existing edition processes. */
final class SaveDataDialog {
    private final PreferenceActivity activity;
    private final SaveDataFiles files;
    private final String title, editionTitle;

    private SaveDataDialog(PreferenceActivity activity, String edition) {
        this.activity = activity;
        files = new SaveDataFiles(new File(Environment.getExternalStorageDirectory(), "Stronghold"), edition);
        editionTitle = GameFiles.title(edition);
        title = "Kelola save data · " + editionTitle;
    }

    static void addPreference(PreferenceActivity activity, PreferenceGroup home, String edition) {
        Preference item = new Preference(activity);
        item.setKey("manage-save-data");
        item.setTitle("Kelola save data");
        item.setSummary("Lihat, ubah nama, dan hapus simpanan " + GameFiles.title(edition));
        home.addPreference(item);
        item.setOnPreferenceClickListener(preference -> {
            new SaveDataDialog(activity, edition).showList();
            return true;
        });
        Preference archive = new Preference(activity);
        archive.setKey("save-data-archive");
        archive.setTitle("Cadangkan / impor simpanan");
        archive.setSummary("Cadangkan simpanan dan profil ketiga edisi ke ZIP");
        archive.setPersistent(false);
        archive.setOnPreferenceClickListener(preference -> {
            activity.startActivity(new android.content.Intent(activity, LauncherActivity.class)
                    .putExtra("showLauncher", true).putExtra("saveDataArchive", true)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP));
            return true;
        });
        home.addPreference(archive);
    }

    private boolean alive() { return !activity.isFinishing() && !activity.isDestroyed(); }

    private void showList() {
        if (!alive()) return;
        AlertDialog loading = new AlertDialog.Builder(activity).setTitle(title)
                .setMessage("Memuat daftar simpanan").setNegativeButton("Batal", null).show();
        new Thread(() -> {
            try {
                List<SaveDataFiles.Entry> entries = files.list();
                activity.runOnUiThread(() -> {
                    if (!alive() || !loading.isShowing()) return;
                    loading.dismiss();
                    AlertDialog.Builder list = new AlertDialog.Builder(activity).setTitle(title)
                            .setNegativeButton("Tutup", null).setNeutralButton("Muat ulang", (dialog, which) -> showList());
                    if (entries.isEmpty()) list.setMessage("Belum ada simpanan untuk versi game ini.\n\n" + files.directoryLabel());
                    else {
                        String[] labels = new String[entries.size()];
                        DateFormat date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
                        for (int i = 0; i < labels.length; i++) {
                            SaveDataFiles.Entry entry = entries.get(i);
                            labels[i] = entry.name + "\n" + date.format(new Date(entry.modified)) + " · "
                                    + Formatter.formatFileSize(activity, entry.size);
                        }
                        list.setItems(labels, (dialog, which) -> showActions(entries.get(which)));
                    }
                    list.show();
                });
            } catch (IOException | SecurityException failure) {
                activity.runOnUiThread(() -> {
                    if (!alive() || !loading.isShowing()) return;
                    loading.dismiss(); showFailure(failure);
                });
            }
        }, "save-list").start();
    }

    private void showActions(SaveDataFiles.Entry entry) {
        new AlertDialog.Builder(activity).setTitle(entry.name)
                .setItems(new String[]{"Ubah nama", "Hapus simpanan"}, (dialog, which) -> {
                    if (which == 0) showRename(entry); else showDelete(entry);
                }).setNegativeButton("Kembali", (dialog, which) -> showList()).show();
    }

    private void showRename(SaveDataFiles.Entry entry) {
        EditText name = new EditText(activity);
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        name.setText(entry.baseName()); name.selectAll();
        AlertDialog dialog = new AlertDialog.Builder(activity).setTitle("Ubah nama simpanan")
                .setMessage("Nama baru (ekstensi .sav tetap disimpan):")
                .setView(name).setPositiveButton("Simpan", null)
                .setNegativeButton("Batal", (view, which) -> showActions(entry)).create();
        dialog.setOnShowListener(view -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
            try {
                files.rename(entry, name.getText().toString());
                dialog.dismiss();
                Toast.makeText(activity, "Nama simpanan disimpan", Toast.LENGTH_SHORT).show(); showList();
            } catch (IOException | SecurityException failure) { name.setError(errorMessage(failure)); }
        }));
        dialog.show();
    }

    private void showDelete(SaveDataFiles.Entry entry) {
        new AlertDialog.Builder(activity).setTitle("Hapus simpanan?")
                .setMessage("Hapus \"" + entry.name + "\" dari " + editionTitle
                        + "? Simpanan yang dihapus tidak dapat dikembalikan.")
                .setNegativeButton("Batal", (dialog, which) -> showActions(entry))
                .setPositiveButton("Hapus", (dialog, which) -> {
                    try {
                        files.delete(entry);
                        Toast.makeText(activity, "Simpanan dihapus", Toast.LENGTH_SHORT).show(); showList();
                    } catch (IOException | SecurityException failure) { showFailure(failure); }
                }).show();
    }

    private void showFailure(Exception failure) {
        if (!alive()) return;
        new AlertDialog.Builder(activity).setTitle("Operasi simpanan gagal")
                .setMessage(errorMessage(failure))
                .setPositiveButton("Muat ulang", (dialog, which) -> showList()).setNegativeButton("Tutup", null).show();
    }

    private static String errorMessage(Exception failure) {
        if (failure instanceof SecurityException || failure instanceof AccessDeniedException)
            return "Akses folder simpanan ditolak. Izinkan akses berkas melalui peluncur, lalu coba lagi.";
        if (failure instanceof NoSuchFileException) return "Simpanan sudah tidak ditemukan. Muat ulang daftar simpanan.";
        return failure.getMessage() == null ? "Operasi simpanan gagal. Coba muat ulang daftar." : failure.getMessage();
    }
}
