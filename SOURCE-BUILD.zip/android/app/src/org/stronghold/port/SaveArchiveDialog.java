package org.stronghold.port;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.widget.LinearLayout;
import android.widget.Button;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Android document-picker UI; archive work runs off the UI thread and excludes running games. */
final class SaveArchiveDialog {
    private static final int EXPORT = 51, IMPORT = 52;
    private final Activity activity;
    private volatile boolean busy;
    private SaveDataArchive.Plan pending;
    private int pendingConflicts;
    private long lastProgress;

    SaveArchiveDialog(Activity activity) { this.activity = activity; }
    private File base() { return new File(Environment.getExternalStorageDirectory(), "Stronghold"); }
    private boolean alive() { return !activity.isFinishing() && !activity.isDestroyed(); }
    boolean busy() { return busy; }
    static boolean accepts(int request) { return request == EXPORT || request == IMPORT; }

    void addButtons(LinearLayout parent) {
        LinearLayout row = Theme.row(activity);
        Button backup = Theme.button(activity, "Cadangkan", false), restore = Theme.button(activity, "Impor", false);
        backup.setOnClickListener(v -> pick(false)); restore.setOnClickListener(v -> pick(true));
        row.addView(backup, Theme.weight(activity, 1, 0)); row.addView(restore, Theme.weight(activity, 1, 8));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.topMargin = Theme.dp(activity, 8);
        parent.addView(row, params);
    }
    void choose() {
        if (busy || !alive()) return;
        new AlertDialog.Builder(activity).setTitle("Cadangkan / impor simpanan")
                .setItems(new String[]{"Cadangkan save data", "Impor cadangan ZIP"}, (dialog, choice) -> pick(choice == 1))
                .setNegativeButton("Tutup", null).show();
    }
    private LanguagePatchFiles.Lease lease() throws IOException {
        try { return new LanguagePatchFiles.Lease(new File(activity.getFilesDir(), "language-game.lock"), false); }
        catch (IOException conflict) { throw new IOException("Simpan lalu tutup semua game sebelum mencadangkan atau mengimpor simpanan.", conflict); }
    }
    private void pick(boolean importing) {
        if (busy) return;
        try (LanguagePatchFiles.Lease ignored = lease()) {
            Intent intent = new Intent(importing ? Intent.ACTION_OPEN_DOCUMENT : Intent.ACTION_CREATE_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE).setType(importing ? "*/*" : "application/zip");
            if (importing) intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"});
            else intent.putExtra(Intent.EXTRA_TITLE, "Stronghold Save " + new SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.ROOT).format(new Date()) + ".zip");
            activity.startActivityForResult(intent, importing ? IMPORT : EXPORT);
        } catch (ActivityNotFoundException missing) { failure(new IOException("Pemilih berkas tidak tersedia di perangkat ini.")); }
        catch (IOException | RuntimeException error) { failure(error); }
    }
    void result(int request, int result, Intent data) {
        if (result != Activity.RESULT_OK || data == null || data.getData() == null || busy) return;
        Uri uri = data.getData();
        if (request == EXPORT) export(uri); else if (request == IMPORT) prepare(uri);
    }

    interface Work { String run(SaveDataArchive.Progress progress) throws Exception; }
    private void task(String title, boolean lockGame, Work work, Runnable after) {
        if (busy || !alive()) return;
        busy = true; lastProgress = 0;
        ProgressDialog progress = new ProgressDialog(activity);
        progress.setTitle(title); progress.setMessage("Menyiapkan berkas");
        progress.setIndeterminate(true); progress.setCancelable(false); progress.show();
        new Thread(() -> {
            String message = null; Exception error = null;
            try (LanguagePatchFiles.Lease ignored = lockGame ? lease() : null) {
                message = work.run((bytes, files) -> {
                    long now = android.os.SystemClock.elapsedRealtime();
                    if (now - lastProgress < 150) return;
                    lastProgress = now;
                    activity.runOnUiThread(() -> {
                        if (alive() && progress.isShowing()) progress.setMessage(files + " berkas · " + android.text.format.Formatter.formatFileSize(activity, bytes));
                    });
                });
            } catch (Exception problem) { error = problem; }
            final String done = message; final Exception failed = error;
            activity.runOnUiThread(() -> {
                busy = false;
                if (!alive()) { discard(); return; }
                progress.dismiss();
                if (failed != null) { discard(); failure(failed); }
                else if (after != null) after.run();
                else if (done != null) new AlertDialog.Builder(activity).setTitle("Save data")
                        .setMessage(done).setPositiveButton("Selesai", null).show();
            });
        }, "save-archive").start();
    }
    private void export(Uri uri) {
        task("Mencadangkan save data", true, progress -> {
            File temporary = File.createTempFile("save-backup-", ".zip", activity.getCacheDir());
            try {
                int count;
                try (OutputStream out = new FileOutputStream(temporary)) { count = SaveDataArchive.backup(base(), out, progress); }
                try (InputStream input = new FileInputStream(temporary);
                     OutputStream output = activity.getContentResolver().openOutputStream(uri, "wt")) {
                    if (output == null) throw new IOException("Tujuan cadangan tidak dapat ditulis.");
                    byte[] bytes = new byte[65536];
                    for (int n; (n = input.read(bytes)) != -1;) output.write(bytes, 0, n);
                    output.flush();
                }
                return count + " berkas simpanan/profil ketiga edisi berhasil dicadangkan.";
            } finally { temporary.delete(); }
        }, null);
    }
    private void prepare(Uri uri) {
        discard();
        task("Memeriksa cadangan simpanan", false, progress -> {
            try (InputStream input = activity.getContentResolver().openInputStream(uri)) {
                if (input == null) throw new IOException("Cadangan tidak dapat dibaca.");
                SaveDataArchive.Plan plan = SaveDataArchive.prepare(input, activity.getCacheDir(), progress);
                try {
                    int conflicts = plan.conflicts(base());
                    synchronized (this) { pending = plan; pendingConflicts = conflicts; }
                } catch (IOException | RuntimeException failure) {
                    try { plan.close(); } catch (IOException cleanup) { failure.addSuppressed(cleanup); }
                    throw failure;
                }
            }
            return null;
        }, this::confirm);
    }
    private void confirm() {
        final SaveDataArchive.Plan plan;
        final int conflicts;
        synchronized (this) { plan = pending; conflicts = pendingConflicts; }
        if (plan == null || !alive()) return;
        new AlertDialog.Builder(activity).setTitle("Impor cadangan?")
                    .setMessage(plan.entries.size() + " berkas simpanan/profil akan diimpor. " + conflicts
                            + " berkas dengan nama yang sama akan diganti. Berkas lain tetap ada.\n\n"
                            + "Cadangan data saat ini dibuat otomatis di Stronghold/Save Backups sebelum impor.")
                    .setPositiveButton("Impor", (dialog, which) -> {
                        synchronized (this) { if (pending != plan) return; pending = null; }
                        task("Mengimpor save data", false, progress -> {
                            try (SaveDataArchive.Plan ignored = plan; LanguagePatchFiles.Lease guard = lease()) {
                                SaveDataArchive.Imported imported = SaveDataArchive.apply(plan, base(),
                                        SaveDataArchive.safeFile(base(), "Save Backups"), progress);
                                return imported.files + " berkas berhasil diimpor.\n\nCadangan sebelum impor:\n" + imported.backup;
                            }
                        }, null);
                    }).setNegativeButton("Batal", null).setOnDismissListener(dialog -> discard()).show();
    }
    synchronized void discard() {
        SaveDataArchive.Plan old = pending; pending = null;
        if (old != null) new Thread(() -> { try { old.close(); } catch (IOException ignored) {} }, "save-import-cleanup").start();
    }
    private void failure(Exception error) {
        if (!alive()) return;
        new AlertDialog.Builder(activity).setTitle("Operasi simpanan gagal")
                .setMessage(error.getMessage() == null ? "Periksa izin penyimpanan lalu coba lagi." : error.getMessage())
                .setPositiveButton("Tutup", null).show();
    }
}
