package org.stronghold.port;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/** Edition-scoped save operations. No game assets or profile settings are enumerated. */
final class SaveDataFiles {
    private final File base;
    private final String profile, gameProfile, saves;
    private static final LinkOption[] NO_LINKS = {LinkOption.NOFOLLOW_LINKS};

    SaveDataFiles(File base, String edition) {
        this.base = base;
        if ("classic".equals(edition)) {
            profile = "userdata-classic"; gameProfile = "Stronghold Crusader"; saves = "Saves";
        } else if ("extreme".equals(edition)) {
            profile = "userdata"; gameProfile = "Stronghold Crusader"; saves = "SavesExtreme";
        } else if ("stronghold".equals(edition)) {
            profile = "userdata-stronghold"; gameProfile = "Stronghold"; saves = "Saves";
        } else throw new IllegalArgumentException("Versi game tidak dikenal.");
    }

    static final class Entry {
        final String name;
        final long size, modified;
        private final SaveDataFiles owner;
        private final Path path;
        private final Object fileKey;
        private final FileTime modifiedTime, createdTime;

        private Entry(SaveDataFiles owner, Path path, BasicFileAttributes attributes) {
            this.owner = owner; this.path = path; name = path.getFileName().toString();
            size = attributes.size(); modified = attributes.lastModifiedTime().toMillis();
            fileKey = attributes.fileKey(); modifiedTime = attributes.lastModifiedTime();
            createdTime = attributes.creationTime();
        }

        String baseName() { return name.substring(0, name.length() - 4); }
    }

    String directoryLabel() {
        return new File(base, profile + "/Documents/" + gameProfile + "/" + saves).getPath();
    }

    synchronized List<Entry> list() throws IOException {
        Path folder = directory(false);
        if (folder == null) return Collections.emptyList();
        List<Entry> entries = new ArrayList<>();
        try (DirectoryStream<Path> children = Files.newDirectoryStream(folder)) {
            for (Path child : children) {
                if (!isSaveName(child.getFileName().toString())) continue;
                try {
                    BasicFileAttributes attributes = Files.readAttributes(child, BasicFileAttributes.class, NO_LINKS);
                    if (attributes.isRegularFile()) entries.add(new Entry(this, child, attributes));
                } catch (NoSuchFileException removedWhileListing) { /* Refresh reflects the remaining saves. */ }
            }
        }
        Collections.sort(entries, (a, b) -> {
            int order = Long.compare(b.modified, a.modified);
            if (order == 0) order = a.name.compareToIgnoreCase(b.name);
            return order == 0 ? a.name.compareTo(b.name) : order;
        });
        return entries;
    }

    synchronized void delete(Entry entry) throws IOException {
        checkedEntry(entry);
        Files.delete(entry.path);
    }

    synchronized void rename(Entry entry, String proposedName) throws IOException {
        Path folder = checkedEntry(entry);
        String stem = checkedName(proposedName);
        String name = stem + entry.name.substring(entry.name.length() - 4);
        if (name.equals(entry.name)) return;
        if (name.equalsIgnoreCase(entry.name))
            throw new IOException("Nama baru harus berbeda, bukan hanya huruf besar atau kecil.");
        // The game resolves every Windows path case-insensitively, including on Linux storage.
        try (DirectoryStream<Path> children = Files.newDirectoryStream(folder)) {
            for (Path child : children) if (name.equalsIgnoreCase(child.getFileName().toString()))
                throw new IOException("Simpanan dengan nama tersebut sudah ada. Gunakan nama lain.");
        }
        // No REPLACE_EXISTING or ATOMIC_MOVE: neither existing saves nor links may be replaced.
        Files.move(entry.path, folder.resolve(name));
    }

    private Path checkedEntry(Entry entry) throws IOException {
        if (entry == null || entry.owner != this) throw new IOException("Simpanan bukan milik versi game ini.");
        Path folder = directory(true);
        if (!folder.equals(entry.path.getParent())) throw new IOException("Lokasi simpanan berubah. Buka ulang daftar simpanan.");
        BasicFileAttributes now = Files.readAttributes(entry.path, BasicFileAttributes.class, NO_LINKS);
        if (!now.isRegularFile() || now.size() != entry.size || !now.lastModifiedTime().equals(entry.modifiedTime)
                || !now.creationTime().equals(entry.createdTime) || !Objects.equals(now.fileKey(), entry.fileKey))
            throw new IOException("Simpanan berubah sejak daftar dibuka. Muat ulang daftar sebelum mencoba lagi.");
        return folder;
    }

    private Path directory(boolean required) throws IOException {
        // /sdcard is an Android alias. Resolve that base, then refuse links within the profile tree.
        Path path = base.getCanonicalFile().toPath();
        try {
            requireDirectory(path);
            for (String name : new String[]{profile, "Documents", gameProfile, saves}) {
                Path match = null;
                // Match files.c's case-insensitive lookup without accepting ambiguous profile roots.
                try (DirectoryStream<Path> children = Files.newDirectoryStream(path)) {
                    for (Path child : children) if (name.equalsIgnoreCase(child.getFileName().toString())) {
                        if (match != null) throw new IOException("Ada dua folder profil dengan nama yang sama. Periksa: " + path);
                        match = child;
                    }
                }
                if (match == null) throw new NoSuchFileException(path.resolve(name).toString());
                requireDirectory(match);
                path = match;
            }
            return path;
        } catch (NoSuchFileException absent) {
            if (!required) return null;
            throw new IOException("Folder simpanan tidak tersedia. Muat ulang daftar simpanan.", absent);
        }
    }

    private static void requireDirectory(Path path) throws IOException {
        if (!Files.readAttributes(path, BasicFileAttributes.class, NO_LINKS).isDirectory())
            throw new IOException("Folder simpanan tidak valid atau berupa tautan: " + path);
    }

    private static boolean isSaveName(String name) {
        return name.length() > 4 && name.toLowerCase(Locale.ROOT).endsWith(".sav");
    }

    private String checkedName(String proposed) throws IOException {
        String name = proposed == null ? "" : proposed.trim();
        if (name.toLowerCase(Locale.ROOT).endsWith(".sav")) name = name.substring(0, name.length() - 4);
        if (name.isEmpty() || name.equals(".") || name.equals("..") || name.endsWith(".") || name.endsWith(" ")
                || name.matches("(?s).*[\\\\/<>:\"|?*\\p{Cntrl}].*"))
            throw new IOException("Isi nama simpanan tanpa / \\ : * ? \" < > | atau titik di akhir.");
        String deviceName = name.split("\\.", 2)[0].toUpperCase(Locale.ROOT);
        if (deviceName.matches("CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]"))
            throw new IOException("Nama tersebut dicadangkan oleh game. Gunakan nama lain.");
        // Native ANSI file enumeration uses Windows-1251 (android/host/strings.c).
        if (!Charset.forName("windows-1251").newEncoder().canEncode(name))
            throw new IOException("Nama berisi karakter yang tidak dapat dibaca game. Gunakan huruf Latin, angka, atau Kiril.");
        String guestPath = "C:\\Users\\Player\\Documents\\" + gameProfile + "\\" + saves + "\\" + name + ".sav";
        if (name.getBytes(StandardCharsets.UTF_8).length + 4 > 255 || guestPath.length() >= 260)
            throw new IOException("Nama simpanan terlalu panjang. Gunakan nama yang lebih pendek.");
        return name;
    }
}
