/* Four reviewed callsites in Stronghold.exe42DB20. Keep original helper
 * results, guest registers/flags and queues; only group eligibility and the
 * callback's local lord permission differ during native control. */
#include "host.h"
#include "touch.h"

extern void sub_004F8320(void);
extern void sub_004F8390(void);
extern void sub_004F8460(void);

static int own_selected_lord(void)
{
    if (!void_vm_readable(0xD47148u, 4) || !void_vm_readable(0x1008144u, 4)) return 0;
    uint32_t count = MEM32(0xD47148u), player = MEM32(0x1008144u);
    if (count < 2 || count > 15001 || player < 1 || player > 8) return 0;
    /* Match4F8320, without calling it: a guest query would consume the
     * group helper's return slot and overwrite its input registers. */
    for (uint32_t id = 1; id < count; ++id) {
        uint32_t unit = 0xD47148u + id * 0x414u;
        if (!void_vm_readable(unit + 0x2CCu, 0x26Eu)) return 0;
        if (MEM16(unit + 0x324u) != 2 || MEM16(unit + 0x538u) || !MEM16(unit + 0x2CCu)) continue;
        if ((int16_t)MEM16(unit + 0x32Eu) != (int32_t)player) return 0;
        if (MEM16(unit + 0x326u) == 55) return 1;
    }
    return 0;
}

void stronghold_original_touch_group(void)
{
    /* Selection precedes mode1 and also occurs through box selection.
     * Use the existing double-click group builder only when this selection
     * includes the player's lord. Other selections keep their old path. */
    if (!stronghold_touch_desktop() && own_selected_lord()) sub_004F8460();
    else sub_004F8390();
}

void stronghold_original_touch_lord(void)
{
    sub_004F8320();
    /* The original query returns a verified own lord ID, and consumes its
     * guest return slot. This offset is relative to that RETURNED ESP.
     * The three callers retain all route/capacity/target checks. */
    if (g_eax && stronghold_touch_lord_control() &&
        g_esp <= UINT32_MAX - 0x18u && void_vm_writable(g_esp + 0x14u, 4) &&
        void_vm_readable(0x1503B24u, 4) && void_vm_readable(0x1503C1Cu, 4) &&
        !MEM32(0x1503B24u) && MEM32(0x1503C1Cu) == 1)
        MEM32(g_esp + 0x14u) = 1;
}
