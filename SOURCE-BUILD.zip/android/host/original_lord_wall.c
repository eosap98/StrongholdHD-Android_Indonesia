/* Narrow permission leaf for Stronghold.exe42F7C5. This is reached only
 * after the original route, unit capability and capacity checks succeed.
 * The native trampoline preserves all CPU state and passes the live guest
 * stack pointer (which the recompiler keeps in w3 at the pinned seam). */
#include "host.h"
#include "touch.h"

int stronghold_original_lord_wall(uint32_t guest_sp)
{
    if (!stronghold_touch_lord_control() || guest_sp > UINT32_MAX - 0x18u ||
        !void_vm_writable(guest_sp + 0x14u, 4) ||
        !void_vm_readable(0x1503B24u, 4) || !void_vm_readable(0x1503C1Cu, 4) ||
        !void_vm_readable(0x16E9358u, 0x70) || !void_vm_readable(0x1008144u, 4) ||
        !void_vm_readable(0xD47148u, 4)) return 0;
    if (MEM32(0x1503B24u) || MEM32(0x1503C1Cu) != 1 || !MEM32(0x16E9358u)) return 0;
    uint32_t tile = MEM32(0x16E93B4u), visual = MEM32(0x16E93A8u);
    uint32_t player = MEM32(0x1008144u), count = MEM32(0xD47148u);
    if (!tile || tile != MEM32(0x16E93C4u) || (visual && visual != tile) ||
        player < 1 || player > 8 || count < 2 || count > 15001 ||
        tile > (UINT32_MAX - 0x11D8E90u - 4u) / 4u) return 0;
    uint32_t flags = 0x11D8E90u + tile * 4u, owner = 0x1327170u + tile;
    if (!void_vm_readable(flags, 4) || !void_vm_readable(owner, 1) ||
        !(MEM32(flags) & 0x10000300u) || ((MEM8(owner) & 7u) + 1u) != player) return 0;

    /* Match4F8320's ordered scan, including its early foreign-unit rejection.
     * Do not alter the selected unit, type, group, destination or tile flags. */
    for (uint32_t id = 1; id < count; ++id) {
        uint32_t unit = 0xD47148u + id * 0x414u;
        if (!void_vm_readable(unit + 0x2CCu, 0x26Eu)) return 0;
        if (MEM16(unit + 0x324u) != 2 || MEM16(unit + 0x538u) || !MEM16(unit + 0x2CCu)) continue;
        if ((int16_t)MEM16(unit + 0x32Eu) != (int32_t)player) return 0;
        if (MEM16(unit + 0x326u) == 0x37) {
            MEM32(guest_sp + 0x14u) = 1;
            return 1;
        }
    }
    return 0;
}
