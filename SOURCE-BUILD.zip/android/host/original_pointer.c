/* Stronghold HD4B83EF reads the desktop hover context before drawing a
 * sprite at the last mouse position. Direct touch has no hovering pointer.
 * Filter only ordinary move/blocked previews at that renderer read; leave
 * ABC544, unit destinations and the separate4E8AD0 destination list intact. */
#include "host.h"
#include "touch.h"

uint32_t stronghold_original_pointer_context(uint32_t context)
{
    if ((context != 3 && context != 5) || stronghold_touch_desktop() ||
        !void_vm_readable(0x1503D38u, 4) || !void_vm_readable(0x1503CE4u, 4) ||
        !void_vm_readable(0x1503B24u, 4) || !void_vm_readable(0x1503C1Cu, 4) ||
        !void_vm_readable(0xD47158u, 4)) return context;
    uint32_t state = MEM32(0x1503D38u);
    if ((state != 12 && state != 14) || MEM32(0x1503CE4u) != UINT32_MAX ||
        MEM32(0x1503B24u) || MEM32(0x1503C1Cu) != 1 || MEM32(0xD47158u) != 1)
        return context;
    /* A rejected submitted tap may still show red while its original edges
     * are processed. The transaction guard ends after the sampled release;
     * it does not grant permission here or make an invalid tile valid. */
    if (context == 5 && stronghold_touch_lord_control()) return context;
    return 0; /* The original renderer has no sprite for context zero. */
}
